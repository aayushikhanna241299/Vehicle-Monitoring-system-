#safe code for dashboard :
# -*- coding: utf-8 -*-
"""
Created on Thu May 16 16:41:21 2024

@author: Aayushi
"""
########################################importing libraries################################################################
import dash
from dash import dcc, html, callback_context
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd
import base64
import io
import os
import tempfile
#import base64
from dash.dependencies import State
from flask import Flask, request
import matplotlib.pyplot as plt
from PIL import Image
import mapcut6
import plotly.graph_objects as go
from datetime import datetime
import requests
import math
import plotly.express as px
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc
import flask
import dash_table
import json
import numpy as np
import plotly.graph_objs as go
from plotly.subplots import make_subplots
import matplotlib.pyplot as plt
from matplotlib.patches import Wedge
import base64
from io import BytesIO
from matplotlib.patches import Wedge, FancyArrow
import dash
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.graph_objects as go
from pmdarima import auto_arima
from datetime import datetime 
from pmdarima import auto_arima
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error
from pmdarima import auto_arima
from twilio.rest import Client

##################################Processing give raw data###############################################################
# Replace 'your_excel_file.xlsx' with the path to your Excel file
excel_file = 'C:/Users/Aayushi/OneDrive/Desktop/Internship/mergefile1.xlsx'

df= pd.read_excel(excel_file)

# Ensure necessary columns are present
required_columns = ['Max_Cell_Temp', 'Min_Cell_Temp', 'Charging_Current', 'MotorCurrent', 'cdate']
for column in required_columns:
    if column not in df.columns:
        raise ValueError(f"Column {column} is missing from the data")


# Filter the data based on the conditions
filtered_data = df[(df['Charging Status'] == 0) & (df['vehicleSpeed'] != 0)]
data = filtered_data[['eDate', 'battery_capacity', 'vehicleSpeed', 'totalDistance']]
data['eDate'] = pd.to_datetime(data['eDate'])

# Resample data to daily intervals
daily_data = data.set_index('eDate').resample('D').mean().reset_index()

# Drop NaN values and zeros
df.dropna(inplace=True)
df.replace(0, pd.NA, inplace=True)

# Convert timestamp to datetime
df['eDate'] = pd.to_datetime(df['eDate'])

# Replace missing values with 0
df.fillna(0, inplace=True)

# Define motion and idle states
def calculate_state(row):
    if row['Charging Status'] == 0 and row['vehicleSpeed'] != 0:
        return 'motion'
    elif row['Charging Status'] == 0 and row['vehicleSpeed'] == 0 and row['Crank Status'] == 1:
        return 'idle'
    else:
        return 'other'

df['state'] = df.apply(calculate_state, axis=1)
        
###########################################Defining all the functions####################################################
first_row_device_id = df['deviceId'].iloc[0]
def select_image(score):
    if score < 0.4:
        return image_src_1
    elif score < 0.6:
        return image_src_2
    elif score < 0.8:
        return image_src_3
    else:
        return image_src_3  # Placeholder for score >= 0.8
    
class HighVoltageSafetyInterlockSystem:
    def __init__(self, file_path):
        self.data = pd.read_excel(file_path)  # Read sensor data from Excel file
        
    def check_safety(self, start_date, end_date):
        # Filter data based on selected date range
        mask = (self.data['eDate'] >= start_date) & (self.data['eDate'] <= end_date)
        filtered_data = self.data.loc[mask]

        # Check sensor readings
        Voltage = filtered_data['Batt_Pack_Voltage'].mean()
        Current = filtered_data['MotorCurrent'].mean()
        if (Voltage > 400).any() or (filtered_data['Current'] > 60).any():
            return False, "High voltage or current detected! Safety compromised."

        # Check interlock switch position (assuming 'Interlock' column contains switch position)
        if (filtered_data['Interlock'] != 'isolated').any():
            return False, "Interlock switch not in isolated position! Safety compromised."

        return True, "Safety checks passed. High voltage system is safe."

# Function to calculate average coolant temperature
def Cal_average_coolant_temp(start_date, end_date):
    if start_date is not None and end_date is not None:
        # Filter the data based on the selected date range
        mask = (df['eDate'] >= start_date) & (df['eDate'] <= end_date)
        filtered_df = df.loc[mask]
        # Calculate the average coolant temperature
        average_coolant_temp = filtered_df['engineCoolantTemp'].mean()
        return average_coolant_temp

# Function to calculate DC/DC temperature
def calculate_dcdc_temp2(start_date, end_date):
    if start_date is not None and end_date is not None:
        # Filter the data based on the selected date range
        mask = (df['eDate'] >= start_date) & (df['eDate'] <= end_date)
        filtered_df = df.loc[mask]
        min_cell_temp = filtered_df['Min_Cell_Temp'].mean()
        max_cell_temp = filtered_df['Max_Cell_Temp'].mean()
        charging_current = filtered_df['Charging_Current'].mean()
        motor_current = filtered_df['MotorCurrent'].mean()
        average_cell_temp = (max_cell_temp + min_cell_temp) / 2
        dcdc_temp = average_cell_temp + 0.1 * (charging_current + motor_current)
        return dcdc_temp, average_cell_temp


def calculate_average_cell_temp(start_date, end_date):
    if start_date is not None and end_date is not None:
        # Filter the data based on the selected date range
        mask = (df['eDate'] >= start_date) & (df['eDate'] <= end_date)
        filtered_df = df.loc[mask]
        min_cell_temp = filtered_df['Min_Cell_Temp'].mean()
        max_cell_temp = filtered_df['Max_Cell_Temp'].mean()
        average_cell_temp = (max_cell_temp + min_cell_temp) / 2
        return average_cell_temp
    
# Function to calculate output power
def calculate_output_power(engineSpeed):
    w = 2 * math.pi * engineSpeed / 60  # Angular velocity in rad/s
    P_out = T * w
    return P_out

# Function to calculate efficiency and power losses
def calculate_efficiency(motor_current, motor_voltage, engineSpeed):
    P_in = motor_current * motor_voltage  # Input power
    P_out = calculate_output_power(engineSpeed) / 1000  # Output power
    if P_in == 0:
        return 0, P_out, 0, 0  # Avoid division by zero
    efficiency = (P_out / P_in) * 100
    P_loss = (P_in - P_out) / 1000
    return P_in, P_out, P_loss, efficiency

# Function to calculate motor temperature
def calculate_motor_temp(P_loss, mean_coolant_temp):
    motor_temp = abs(((P_loss * R_theta) / 1000) - mean_coolant_temp)
    return motor_temp

# Constants
T = 3216  # Torque in Nm
R_theta = 0.5  # Thermal resistance in °C/W

# Function to calculate discharge current
def calculate_discharge_current(power_input_diff, voltage_diff):
    if voltage_diff == 0:
        return float('inf')  # Prevent division by zero
    return power_input_diff / voltage_diff

# Function to calculate battery capacity
def calculate_battery_capacity(discharge_current, discharge_time):
    return discharge_current * discharge_time

# Step 3: Create the Gauge Chart
def create_gauge_chart_degrade(degradation_percentage):
    colors = ['#55A6C9', '#55A6C9', '#23A4CD', '#23A4CD', '#23A4CD', '#0597B7', '#0597B7']
    values = [100, 80, 60, 40, 20, 0, -20, -40]
    x_axis_vals = [0, 0.44, 0.88, 1.32, 1.76, 2.2, 2.64]

    fig = plt.figure(figsize=(9, 9))
    ax = fig.add_subplot(projection="polar")
    ax.bar(x=x_axis_vals, width=0.5, height=0.5, bottom=2, linewidth=3, edgecolor="white", color=colors, align="edge")

    for loc, val in zip(x_axis_vals, values):
        plt.annotate(val, xy=(loc, 2.5), ha="right" if val <= 20 else "left")

    plt.annotate(f"{degradation_percentage:.1f}%", xytext=(0, 0), xy=(1.1, 2.0),
                 arrowprops=dict(arrowstyle="wedge,tail_width=0.5", color="black"),
                 bbox=dict(boxstyle="circle", facecolor="black", linewidth=2.0),
                 fontsize=45, color="white")

    plt.title("Battery Degradation Gauge Chart", loc="center", pad=20, fontsize=35, fontweight="bold")

    ax.set_axis_off()

    # Convert plot to PNG image
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    return base64.b64encode(buf.read()).decode('utf-8')

# Ensure the 'cdate' column is in datetime format
df['cdate'] = pd.to_datetime(df['cdate'])


# Convert 'eDate' column to datetime type
df['eDate'] = pd.to_datetime(df['eDate'])

# Define the colors, values, and coolant temperatures
colors = ['#499B34', '#499B34', '#F0D90D', '#F0D90D', '#F0D90D', '#CC2828', '#CC2828', '#499B34']
values = [100, 80, 60, 40, 20, 0, -20, -40]
x_axis_vals = [0, 0.44, 0.88, 1.32, 1.76, 2.2, 2.64]

def create_gauge_chart(colors, values, average_coolant_temp):
    rotation_angle = 90  # Rotate by 90 degrees

    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(projection="polar")
    bars = ax.bar(x=x_axis_vals, width=0.5, height=0.5, bottom=2, linewidth=3, edgecolor="white", color=colors, align="edge")

    # Define temperature zones
    red_zone_upper_limit = 40  # Upper limit for red zone
    yellow_zone_upper_limit = 30  # Upper limit for yellow zone

    # Check which zone the average coolant temperature falls into and set needle color accordingly
    if average_coolant_temp >= red_zone_upper_limit:
        needle_color = 'red'
        angle = 157.5  # Angle for red zone
    elif average_coolant_temp >= yellow_zone_upper_limit:
        needle_color = 'yellow'
        angle = 102.5  # Angle for yellow zone
    else:
        needle_color = 'green'
        angle = 45.5  # Angle for green zone

    # Plot the needle with annotation
    plt.annotate(f"{average_coolant_temp:.1f}°C", xytext=(angle, 0), xy=(1.1, 2.0),
                 arrowprops=dict(arrowstyle="wedge,tail_width=0.5", color="black"),
                 bbox=dict(boxstyle="circle", facecolor="black"),
                 fontsize=20, color="white")

    #plt.title("Coolant Gauge Chart", loc="center", pad=20, fontsize=25, fontweight="bold")
    ax.set_axis_off()
    
    # Save the chart as an image
    image_path = "gauge_chart.png"
    plt.savefig(image_path)
    plt.close()

    # Convert the image to base64
    with open(image_path, "rb") as img_file:
        encoded_image = base64.b64encode(img_file.read()).decode()

    return encoded_image

# Calculate the initial average coolant temperature for the full date range and create the gauge chart
initial_average_coolant_temp = df['engineCoolantTemp'].mean()
initial_encoded_image = create_gauge_chart(colors, values, initial_average_coolant_temp)


# Function to calculate DC/DC temperature
def calculate_dcdc_temp(max_cell_temp, min_cell_temp, charging_current, motor_current):
    average_cell_temp = (max_cell_temp + min_cell_temp) / 2
    dcdc_temp = average_cell_temp + 0.1 * (charging_current + motor_current)
    return dcdc_temp
# Define the colors, values, and coolant temperatures
colors = ['#499B34', '#499B34', '#F0D90D', '#F0D90D', '#F0D90D', '#CC2828', '#CC2828', '#499B34']
values = [100, 80, 60, 40, 20, 0, -20, -40]
x_axis_vals = [0, 0.44, 0.88, 1.32, 1.76, 2.2, 2.64]

# Function to create gauge chart
def create_gauge_chart1(colors, values, dcdc_temp):
    #x_axis_vals = [0, 0.44, 0.88, 1.32, 1.76, 2.2, 2.64]
    #rotation_angle = 90  # Rotate by 90 degrees

    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(projection="polar")
    #bars = ax.bar(x=x_axis_vals, width=0.5, height=0.5, bottom=2, linewidth=3, edgecolor="white", color=colors, align="edge")

    # Define temperature zones
    red_zone_upper_limit = 40  # Upper limit for red zone
    yellow_zone_upper_limit = 30  # Upper limit for yellow zone

    # Check which zone the dcdc_temp falls into and set needle color accordingly
    if dcdc_temp >= red_zone_upper_limit:
        #needle_color = 'red'
        angle = 157.5  # Angle for red zone
    elif dcdc_temp >= yellow_zone_upper_limit:
        #needle_color = 'yellow'
        angle = 102.5  # Angle for yellow zone
    else:
        #needle_color = 'green'
        angle = 45.5  # Angle for green zone

    # Plot the needle with annotation
    plt.annotate(f"{dcdc_temp:.1f}°C", xytext=(angle, 0), xy=(1.1, 2.0),
                 arrowprops=dict(arrowstyle="wedge,tail_width=0.5", color="black"),
                 bbox=dict(boxstyle="circle", facecolor="black"),
                 fontsize=20, color="white")

    #plt.title("DCDC Gauge Chart", loc="center", pad=20, fontsize=25, fontweight="bold")
    ax.set_axis_off()
    
    # Save the chart as an image
    image_path = "gauge_chart_dc.png"
    plt.savefig(image_path)
    plt.close()

    # Convert the image to base64
    with open(image_path, "rb") as img_file:
        encoded_image = base64.b64encode(img_file.read()).decode()

    return encoded_image

# Define the colors, values, and cell temperature zones
colors = ['#499B34', '#499B34', '#F0D90D', '#F0D90D', '#F0D90D', '#CC2828', '#CC2828', '#499B34']
values = [100, 80, 60, 40, 20, 0, -20, -40]
x_axis_vals = [0, 0.44, 0.88, 1.32, 1.76, 2.2, 2.64]

def create_gauge_chart_cell(colors, values, average_cell_temp):
    # Rotate by 90 degrees
    #rotation_angle = 90  

    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(projection="polar")
    #bars = ax.bar(x=x_axis_vals, width=0.5, height=0.5, bottom=2, linewidth=3, edgecolor="white", color=colors, align="edge")

    # Define temperature zones
    red_zone_upper_limit = 40  # Upper limit for red zone
    yellow_zone_upper_limit = 30  # Upper limit for yellow zone

    # Determine the needle color based on average cell temperature
    if average_cell_temp >= red_zone_upper_limit:
        needle_color = 'red'
        angle = 157.5  # Angle for red zone
    elif average_cell_temp >= yellow_zone_upper_limit:
        needle_color = 'yellow'
        angle = 102.5  # Angle for yellow zone
    else:
        needle_color = 'green'
        angle = 45.5  # Angle for green zone

    # Plot the needle with annotation
    plt.annotate(f"{average_cell_temp:.1f}°C", xytext=(angle, 0), xy=(1.1, 2.0),
                 arrowprops=dict(arrowstyle="wedge,tail_width=0.5", color="black"),
                 bbox=dict(boxstyle="circle", facecolor="black"),
                 fontsize=20, color="white")

    #plt.title("Cell Temperature Gauge Chart", loc="center", pad=20, fontsize=25, fontweight="bold")
    ax.set_axis_off()
    
    # Save the chart as an image
    image_path = "gauge_chart_cell_temp.png"
    plt.savefig(image_path)
    plt.close()

    # Convert the image to base64
    with open(image_path, "rb") as img_file:
        encoded_image = base64.b64encode(img_file.read()).decode()

    return encoded_image

# Define the colors, values, and coolant temperatures
colors = ['#499B34', '#499B34', '#F0D90D', '#F0D90D', '#F0D90D', '#CC2828', '#CC2828', '#499B34']
values = [100, 80, 60, 40, 20, 0, -20, -40]
x_axis_vals = [0, 0.44, 0.88, 1.32, 1.76, 2.2, 2.64]

def create_gauge_chart_motor(colors, values, average_motor_current):
    rotation_angle = 90  # Rotate by 90 degrees

    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(projection="polar")
    bars = ax.bar(x=x_axis_vals, width=0.5, height=0.5, bottom=2, linewidth=3, edgecolor="white", color=colors, align="edge")

    # Define temperature zones
    red_zone_upper_limit = 40  # Upper limit for red zone
    yellow_zone_upper_limit = 30  # Upper limit for yellow zone

    # Check which zone the average coolant temperature falls into and set needle color accordingly
    if average_motor_current >= red_zone_upper_limit:
        needle_color = 'red'
        angle = 157.5  # Angle for red zone
    elif average_motor_current >= yellow_zone_upper_limit:
        needle_color = 'yellow'
        angle = 102.5  # Angle for yellow zone
    else:
        needle_color = 'green'
        angle = 45.5  # Angle for green zone

    # Plot the needle with annotation
    plt.annotate(f"{average_motor_current:.1f}KW", xytext=(angle, 0), xy=(1.1, 2.0),
                 arrowprops=dict(arrowstyle="wedge,tail_width=0.5", color="black"),
                 bbox=dict(boxstyle="circle", facecolor="black"),
                 fontsize=20, color="white")

    plt.title("Gauge for Motor current", loc="center", pad=20, fontsize=25, fontweight="bold")
    ax.set_axis_off()
    
    # Save the chart as an image
    image_path = "gauge_chart.png"
    plt.savefig(image_path)
    plt.close()

    # Convert the image to base64
    with open(image_path, "rb") as img_file:
        encoded_image = base64.b64encode(img_file.read()).decode()

    return encoded_image

# Calculate the initial average coolant temperature for the full date range and create the gauge chart
initial_average_coolant_temp = df['engineCoolantTemp'].mean()
initial_encoded_image = create_gauge_chart(colors, values, initial_average_coolant_temp)


# Function to get route from OSRM API
def get_directions(coords):
    base_url = 'http://router.project-osrm.org/route/v1/driving/'
    waypoints = ';'.join([f"{lon},{lat}" for lat, lon in coords])
    response = requests.get(f"{base_url}{waypoints}?overview=full&geometries=geojson")

    if response.status_code == 200:
        response_json = response.json()
        if response_json['routes']:
            return response_json['routes'][0]['geometry']['coordinates']
    return []

# Function to add direction arrows
def add_direction_arrows(route_lon, route_lat):
    arrow_lons = []
    arrow_lats = []
    arrow_angles = []

    for i in range(len(route_lon) - 1):
        lon_start = route_lon[i]
        lat_start = route_lat[i]
        lon_end = route_lon[i + 1]
        lat_end = route_lat[i + 1]

        arrow_lons.append((lon_start + lon_end) / 2)
        arrow_lats.append((lat_start + lat_end) / 2)

        angle = math.degrees(math.atan2(lat_end - lat_start, lon_end - lon_start))
        arrow_angles.append(angle)

    arrows = go.Scattermapbox(
        lon=arrow_lons,
        lat=arrow_lats,
        mode='markers',
        marker=dict(
            symbol='triangle-up',
            size=25,  # Increase arrow size here
            angleref='previous',
            angle=arrow_angles,
            color='blue'
        ),
        showlegend=False
    )

    return arrows

# Define utility functions
def save_file(contents, filename):
    """Decode and store a file uploaded with Plotly Dash."""
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    with tempfile.NamedTemporaryFile(delete=False, suffix=filename) as temp_file:
        temp_file.write(decoded)
        return temp_file.name

def parse_contents(contents, filename):
    file_path = save_file(contents, filename)
    # Read the Excel file into a DataFrame
    df = pd.read_excel(file_path)
    return df, file_path


# Motor constants
T = 3216  # Torque in Nm
pi = math.pi  # Pi
R_theta = 0.5  # Thermal resistance in °C/W

# Function to calculate output power
def calculate_output_power(engineSpeed):
    w = 2 * pi * engineSpeed / 60  # Angular velocity in rad/s
    P_out = T * w
    return P_out

# Function to calculate efficiency and power losses
def calculate_efficiency(I, V, engineSpeed):
    P_in = I * V  # Input power
    P_out = (calculate_output_power(engineSpeed))/1000  # Output power
    if P_in == 0:
        return 0, P_out, 0, 0  # Avoid division by zero
    efficiency = (P_out / P_in)*100
    P_loss = (P_in - P_out)/1000
    return P_in, P_out, P_loss, efficiency

# Function to calculate motor temperature
def calculate_motor_temp(P_loss, mean_coolant_temp):
    motor_temp = abs(((P_loss * R_theta)/1000) - mean_coolant_temp)
    return motor_temp

# Function to draw the gauge chart and return it as an image
def draw_gauge_chart(motor_temp):
    fig, ax = plt.subplots()

    # Draw circle
    circle = plt.Circle((0.5, 0.5), 0.4, color='black', ec='red', lw=6)
    ax.add_artist(circle)

    # Calculate needle angle based on motor temperature
    needle_angle = (motor_temp / 100) * 360

    # Draw needle
    needle_length = 0.2
    needle_end_x = 0.5 + needle_length * np.cos(np.deg2rad(needle_angle))
    needle_end_y = 0.5 + needle_length * np.sin(np.deg2rad(needle_angle))
    ax.plot([0.5, needle_end_x], [0.5, needle_end_y], color='yellow', linewidth=3)

    # Draw full circle scale markings
    num_marks = 10
    mark_length = 0.005
    start_radius = 0.23
    mark_radius = 0.25
    for i in range(num_marks):
        angle = (360 / num_marks) * i
        x_start = 0.5 + start_radius * np.cos(np.deg2rad(angle))
        y_start = 0.5 + start_radius * np.sin(np.deg2rad(angle))
        x_end = 0.5 + mark_radius * np.cos(np.deg2rad(angle))
        y_end = 0.5 + mark_radius * np.sin(np.deg2rad(angle))
        ax.plot([x_start, x_end], [y_start, y_end], color='white', linewidth=2)

    ax.set_aspect('equal')
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')  # Turn off the axis

    # Annotate motor temperature inside the circle
    ax.annotate(f'{motor_temp:.2f}°C', xy=(0.5, 0.5), xytext=(0.5, 0.5),
                fontsize=19, color='white', ha='center', va='center',fontweight=11)

    # Save the plot to a BytesIO object and encode as base64
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    img_data = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()
    
    return img_data


def assign_efficiency_score(efficiency):
    if efficiency >= 90:
        return 90
    elif 80 <= efficiency < 90:
        return 70
    elif 70 <= efficiency < 80:
        return 50
    elif 60 <= efficiency < 70:
        return 30
    else:
        return 10

def assign_torque_score(torque):
    diff = T - torque
    if 50 <= diff <= 500:
        return 90
    elif 550 <= diff <= 1000:
        return 70
    elif 1500 <= diff <= 2000:
        return 50
    elif 2500 <= diff <= 3000:
        return 30
    else:
        return 10  

def assign_power_dissipation_score(P_loss):
    if P_loss <= 100:
        return 100
    elif 100 < P_loss <= 200:
        return 80
    elif 200 < P_loss <= 300:
        return 60
    elif 300 < P_loss <= 400:
        return 40
    else:
        return 20

def assign_input_power_score(P_in):
    if P_in >= 2000:
        return 90
    elif 1500 <= P_in < 2000:
        return 70
    elif 1000 <= P_in < 1500:
        return 50
    elif 500 <= P_in < 1000:
        return 30
    else:
        return 10

# Calculate SOC
def calculate_soc(df):
    min_cell_v = df['Min_Cell_V'].min()
    max_cell_v = df['Max_Cell_V'].max()
    df['SOC (%)'] = ((df['Batt_Pack_Voltage'] - df['Min_Cell_V']) / (max_cell_v - min_cell_v)) * 100
    return df

df = calculate_soc(df)

# Calculate average maximum and minimum cell temperatures
def calculate_avg_temp(df):
    avg_max_temp = df['Max_Cell_Temp'].mean()
    avg_min_temp = df['Min_Cell_Temp'].mean()
    return avg_max_temp, avg_min_temp

avg_max_temp, avg_min_temp = calculate_avg_temp(df)

# Define function to calculate score based on voltage range
def calculate_voltage_score(voltage, threshold_ranges):
    for low, high, score in threshold_ranges:
        if low <= voltage <= high:
            return score
    return 0  # Default score if voltage is outside all ranges

# Define function to calculate score based on temperature range
def calculate_temperature_score(temp, threshold_ranges):
    for low, high, score in threshold_ranges:
        if low <= temp <= high:
            return score
    return 0  # Default score if temperature is outside all ranges

# Define threshold ranges and corresponding scores for Max cell voltage
max_cell_v_thresholds = [
    (4.1, 4.2, 90),
    (4.0, 4.1, 70),
    (3.0, 3.1, 50),
    (2.0, 2.1, 30)
]

# Define threshold ranges and corresponding scores for Min cell voltage
min_cell_v_thresholds = [
    (3.7, 3.8, 90),
    (4.0, 4.1, 70),
    (3.0, 3.4, 50),
    (2.0, 3.3, 30)
]

# Define threshold ranges and corresponding scores for Max cell temperature
max_cell_temp_thresholds = [
    (20, 40, 90),
    (41, 50, 70),
    (51, 60, 50),
    (61, 70, 30)
]

# Define threshold ranges and corresponding scores for Min cell temperature
min_cell_temp_thresholds = [
    (20, 40, 90),
    (41, 50, 70),
    (51, 60, 50),
    (61, 70, 30)
]
# Function to find start and end indices of cycles
def find_start_end_indices(data_series, condition_value):
    start_index = None
    end_index = None
    start_i = []
    end_i = []

    for index, value in enumerate(data_series):
        if value == condition_value:
            if start_index is None:
                start_index = index
            end_index = index
        elif end_index is not None:
            start_i.append(start_index)
            end_i.append(end_index)
            start_index = None
            end_index = None

    if start_index is not None:
        start_i.append(start_index)
        end_i.append(end_index)

    return start_i, end_i

# Function to calculate discharge current
def calculate_discharge_current(power_input_diff, voltage_diff):
    if voltage_diff == 0:
        return float('inf')  # Prevent division by zero
    return power_input_diff / voltage_diff

# Function to calculate battery capacity
def calculate_battery_capacity(discharge_current, discharge_time):
    return discharge_current * discharge_time

#######################Processing Data for energy production cards######################################################
# Ensure eDate is in datetime format
df['eDate'] = pd.to_datetime(df['eDate'])

# Create a new column for the 3-hour batches
df['3hr_batch'] = df['eDate'].dt.floor('3H')

# Filter the data based on the specified conditions
filtered_df = df[(df['Charging Status'] == 0) & (df['vehicleSpeed'] != 0)]

# Function to calculate the difference between the last and first value of a column
def calculate_difference(group):
    return group.iloc[-1] - group.iloc[0]

# Function to find start and end indices of charging cycles
def find_start_end_indices(data_series, condition_value):
    start_index = None
    end_index = None
    start_i = []
    end_i = []

    for index, value in enumerate(data_series):
        if value == condition_value:
            if start_index is None:
                start_index = index
            end_index = index
        elif end_index is not None:
            start_i.append(start_index)
            end_i.append(end_index)
            start_index = None
            end_index = None

    if start_index is not None:
        start_i.append(start_index)
        end_i.append(end_index)

    return start_i, end_i

# Assuming your Excel sheet has columns named 'eDate', 'battery_capacity', 'average_speed', and 'distance_traveled'
# You may need to adjust the column names accordingly
data = df[['eDate', 'battery_capacity', 'vehicleSpeed', 'totalDistance']]

# Convert eDate column to datetime object
data['eDate'] = pd.to_datetime(data['eDate'])

# Resample data to daily intervals
daily_data = data.set_index('eDate').resample('D').mean().reset_index()

# Filter data for training Auto ARIMA
train_data = daily_data[['eDate', 'totalDistance']]

# Fit Auto ARIMA model
model = auto_arima(train_data['totalDistance'], seasonal=False, trace=True)

# Forecast
n_periods = 7  # Number of periods to forecast (one week)
forecast, conf_int = model.predict(n_periods=n_periods, return_conf_int=True)

# Generate dates for forecasted periods (next week)
# Generate dates for forecasted periods (next week starting from March 23rd)
forecast_start_date = datetime.strptime('2024-03-23', '%Y-%m-%d')
n_periods = 7  # forecasting for next 7 days
forecast_dates = pd.date_range(start=forecast_start_date, periods=n_periods, freq='D')

# Plotly figure
fig = go.Figure()

# Add observed data
fig.add_trace(go.Scatter(x=train_data['eDate'], y=train_data['totalDistance'], mode='lines', name='Observed'))

# Add forecasted data
fig.add_trace(go.Scatter(x=forecast_dates, y=forecast, mode='lines', name='Forecast'))

# Update layout
fig.update_layout(title='Auto ARIMA Forecast for Next Week (Daily Basis)',
                  xaxis_title='Date',
                  yaxis_title='Distance Traveled')

# Load data from an Excel file
file_path = 'C:/Users/Aayushi/OneDrive/Desktop/Internship/mergefile1.xlsx'
data = pd.read_excel(file_path)

# Convert timestamp to datetime
data['eDate'] = pd.to_datetime(data['eDate'])

# Preprocess Motor Power data
motor_data = data[['eDate', 'MotorCurrent', 'MotorVoltage']].dropna()
motor_data['MotorCurrent'] = pd.to_numeric(motor_data['MotorCurrent'], errors='coerce')
motor_data['MotorVoltage'] = pd.to_numeric(motor_data['MotorVoltage'], errors='coerce')
motor_data.dropna(inplace=True)
motor_data = motor_data[(motor_data['MotorCurrent'] != 0) & (motor_data['MotorVoltage'] != 0)]
motor_data['product'] = motor_data['MotorCurrent'] * motor_data['MotorVoltage']
daily_motor_data = motor_data.set_index('eDate').resample('D').mean().fillna(method='ffill').reset_index()

# Split the data into training and testing sets (80% training, 20% testing)
train_size = int(len(daily_motor_data) * 0.8)
train_motor, test_motor = daily_motor_data['product'][:train_size], daily_motor_data['product'][train_size:]

# Fit the ARIMA model for Motor Power
motor_model = ARIMA(train_motor, order=(5, 1, 0))
motor_model_fit = motor_model.fit()

# Forecast the next 7 days for Motor Power
forecast_motor_next_week = motor_model_fit.forecast(steps=7)
forecast_motor_index = pd.date_range(start=daily_motor_data['eDate'].iloc[-1] + pd.Timedelta(days=1), periods=7, freq='D')

# Preprocess Cell Max Temp data
temp_data = data[['eDate', 'Max_Cell_Temp']].dropna()
daily_temp_data = temp_data.set_index('eDate').resample('D').mean().fillna(method='ffill').reset_index()

# Fit the Auto ARIMA model for Cell Max Temp
temp_model = auto_arima(daily_temp_data['Max_Cell_Temp'], seasonal=False, trace=True)
forecast_temp, conf_int_temp = temp_model.predict(n_periods=7, return_conf_int=True)

# Generate dates for forecasted periods
forecast_temp_start_date = datetime.strptime('2024-03-23', '%Y-%m-%d')
forecast_temp_dates = pd.date_range(start=forecast_temp_start_date, periods=7, freq='D')

# Preprocess Battery Lifetime data
battery_data = data[['eDate', 'totalDistance']].dropna()
daily_battery_data = battery_data.set_index('eDate').resample('D').mean().fillna(method='ffill').reset_index()

# Fit the Auto ARIMA model for Battery Lifetime
battery_model = auto_arima(daily_battery_data['totalDistance'], seasonal=False, trace=True)
forecast_battery, conf_int_battery = battery_model.predict(n_periods=7, return_conf_int=True)

# Generate dates for forecasted periods
forecast_battery_start_date = datetime.strptime('2024-03-23', '%Y-%m-%d')
forecast_battery_dates = pd.date_range(start=forecast_battery_start_date, periods=7, freq='D')

######################################################Creating dictionaries#############################################
# Twilio configuration
account_sid = 'AC4423f9f3c93914eda2d0015018c6616d'
auth_token = '94c8fce35cde5202add91dc6cec59728'
client = Client(account_sid, auth_token)
from_phone_number = '+12183944051'
to_phone_number = '+919818781784'

# Define the data for the table
data = [
    {"Diagnostic Trouble Codes": "Catalyst System", "Code": "P0430"},
    {"Diagnostic Trouble Codes": "Brake Switch Circuit", "Code": "C0281"},
    {"Diagnostic Trouble Codes": "High Voltage Interlock", "Code": "U0002"},
    {"Diagnostic Trouble Codes": "Battery Pack Thermal", "Code": "B1010"},
    {"Diagnostic Trouble Codes": "Invalid Data Received", "Code": "U0004"},
    {"Diagnostic Trouble Codes": "Electronics Coolant", "Code": "P0A03"}
]

maintenance_centers = [
     {'name':'Chandigarh Auto Repair','lat':30.71072,'lon':76.74342},
     {'name':'Auto Car Scen','lat':30.70508,'lon':76.76202},
     {'name':'Manoj Auto Centre','lat':30.70508,'lon':76.76202},
     {'name':'Chandigarh Auto Care','lat':30.70496,'lon':76.75598},
     {'name':'Aman Auto Repair','lat':30.70508,'lon':76.76202},
     {'name':'Manoj Auto Centre','lat':30.69158,'lon':76.756371},
     {'name':'Karan Automobile','lat':30.710457,'lon':76.762044},
     {'name':'Mohan CNG Car Center','lat':30.69157,'lon':76.75628},
     {'name':'Bay2Mechanic','lat':30.69195,'lon':76.7685},
     {'name':'JMD Auto Repair','lat':30.72429,'lon':76.74155},
     {'name':'Mahindra Auto','lat':30.73743,'lon':76.73444},
     {'name':'Maruti Authorised Service Centre','lat':30.73924,'lon':76.76573},
     {'name':'Royal Enfield Service Center Manmohan Auto Stores','lat':30.70295,'lon':76.80201},
     {'name':'Om Motor Garage','lat':43.2048,'lon':-75.44359},
     {'name':'Rajinder Car Repair','lat':30.72429,'lon':76.74155},
     {'name':'Sachin Auto','lat':30.72429,'lon':76.74155},
     {'name':'Raj Auto Centre','lat':30.71072,'lon':76.74342},
     {'name':'GoMechanic Car Repair Shop Chandigarh','lat':31.2453,'lon':76.6554},
     {'name':'Sachin Auto','lat':30.7334421,'lon':76.7797143},
     {'name':'Auto Car Scen','lat':31.2453,'lon':76.6554},
     {'name':'Car Battery, Car Mechanic, Repairs & Service','lat':30.70508,'lon':76.76202},
     {'name':'Nexa Service (Autovogue)','lat':3.00217,'lon':101.62399},
     {'name':'GoMechanic Car Repair Shop Chandigarh','lat':30.73375,'lon':76.73783},
     {'name':'Balaji Autoss','lat':30.72891,'lon':76.74943},
     {'name':'Khalsa Auto Centre','lat':30.7339,'lon':76.73824}
]

# Sample image URLs
image_src_1 = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbKwDfA-lS2_zOd5eFtRY42L0STQilojdlHw&s"
image_src_2 = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwprk2MEF4oAyhLGU2Qvk4yIGCguI7ohOVU0pAxWQ-Wg&s"
image_src_3 = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuweJDC6MzEiUqEl7sGAxvRnZpvdKQgXCiEw&s"

        
######################################### Defininng App  ###############################################################
# Use a single dash.Dash instance
app = dash.Dash(__name__, 
                suppress_callback_exceptions=True, 
                external_stylesheets=[
                    dbc.themes.BOOTSTRAP, 
                    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css'
                ])
# Define the sidebar with an additional link for Page 6
sidebar = html.Div(
    children=[
        html.Div(
            children=[
                html.Div(
                    children=[
                        html.Div(
                            html.Img(src='https://www.seekpng.com/png/detail/186-1861623_volvo-eicher-logo-png.png', style={'height': '54px', 'width': '54px', 'border-radius': '50%'}),
                            style={'border': '1px solid white', 'border-radius': '50%', 'overflow': 'hidden', 'height': '54px', 'width': '54px', 'padding': '2px', 'margin-top': '30px','margin-bottom': '50px'}
                        )
                    ],
                    style={'display': 'flex', 'justify-content': 'center'}
                ),
                html.A([
                    html.I(className="fas fa-home", style={'margin-right': '10px'}),
                    'Overview'
                ], id='page-1-link', href='#', style={'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B', 'margin-bottom': '20px'}),
                html.A([
                    html.I(className="fas fa-battery-full", style={'margin-right': '10px','transform': 'rotate(270deg)'}),
                    'Battery Health'
                ], id='page-2-link', href='#', style={'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#6D6F71', 'margin-bottom': '20px'}),
                html.A([
                    html.I(className="fa fa-bolt", style={'margin-right': '10px'}),
                    'Cell Health'
                ], id='page-3-link', href='#', style={'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B', 'margin-bottom': '20px'}),
                html.A([
                    html.I(className="fa fa-cog", style={'margin-right': '10px'}),
                    'Motor Health'
                ], id='page-4-link', href='#', style={'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B', 'margin-bottom': '20px'}),
                html.A([
                    html.I(className="fa fa-lightbulb", style={'margin-right': '10px'}),
                    'Energy Consumption Pattern'
                ], id='page-5-link', href='#', style={'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B', 'margin-bottom': '20px'}),
                html.A([
                    html.I(className="fas fa-map", style={'margin-right': '10px'}),
                    'MAP'  # Add the new link for Page 6
                ], id='page-6-link', href='#', style={'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B', 'margin-bottom': '20px'})
            ]
        )
    ],
    style={'flex': '0 0 200px', 'height': '150vh', 'backgroundColor': '#0E396B'}
)
upload_component = dcc.Upload(
id='upload-data',
children=html.Div([
    'Select Files '
    
]),
style={
    'width': '100px',  # Adjust width as needed
        'height': '30px',
        'lineHeight': '30px',  # Set same value as height to center text vertically
        'borderWidth': '1px',
        'borderStyle': 'solid',
        'borderRadius': '5px',
        'textAlign': 'center',
        'margin': '15px',
        'backgroundColor': '#0E396B',  # Set background color to grey
        'color': 'white'  # Set text color to white

    }
)
Date1 = dcc.DatePickerRange(
    id='date-picker-range',
    display_format='Y-M-D',
    start_date_placeholder_text="Start Date",
    end_date_placeholder_text="End Date",
    )

Date2 = dcc.DatePickerRange(
    id='date-picker-range2',
    start_date_placeholder_text="Start Date",
    end_date_placeholder_text="End Date",
    display_format='YYYY-MM-DD',
    start_date='2024-03-15',
    end_date='2024-03-23'
)

            



########################################## Navigation bar and side bar ##########################################
# Get the current directory and set the file paths
current_directory = os.path.dirname(os.path.abspath(__file__))
text_file_path = os.path.join(current_directory, 'help.txt')
word_file_path = os.path.join(current_directory, 'help.docx')
#Navigation Bar definition 
#Navigation Bar definition 
navbar = html.Div(
    children=[
        html.Div(
            children=[
                html.Img(src='https://www.motorindiaonline.in/wp-content/uploads/2015/06/VE-Commercial-Vehicles-logo.jpg', style={'height': '50px', 'width': 'auto', 'margin-right': '10px'}),
                html.H2(style={'color': 'black', 'padding': '10px', 'backgroundColor': 'white', 'margin': '0'}),
                # YouTube button
                html.A(
                    children=[
                        html.Button("Go to YouTube", style={
                            'backgroundColor': '#BC4343',
                            'color': 'white',
                            'border': 'none',
                            'padding': '10px 20px',
                            'textAlign': 'center',
                            'textDecoration': 'none',
                            'display': 'inline-block',
                            'fontSize': '16px',
                            'margin': '4px 2px',
                            'cursor': 'pointer',
                            'borderRadius': '5px'
                        })
                    ],
                    href="https://www.youtube.com/watch?v=8IXZqCBwG9o",
                    target="_blank"
                ),
                html.Div([
                    html.Button('Emergency Call', id='call-button', n_clicks=0,style={
                        'backgroundColor': '#0E396B',
                        'color': 'white',
                        'border': 'none',
                        'padding': '10px 20px',
                        'textAlign': 'center',
                        'textDecoration': 'none',
                        'display': 'inline-block',
                        'fontSize': '16px',
                        'margin': '4px 2px',
                        'cursor': 'pointer',
                        'borderRadius': '5px'
                    }),
                    html.Div(id='call-status')
                ]),
                html.Div(
                    children=[
                        # Styling the Help button
                        html.Button([html.I(className="fas fa-lightbulb"), "Help"], id='open-help-button', n_clicks=0, style={
                            'backgroundColor': '#0E396B',
                            'color': 'white',
                            'border': 'none',
                            'padding': '10px 20px',
                            'textAlign': 'center',
                            'textDecoration': 'none',
                            'display': 'inline-block',
                            'fontSize': '16px',
                            'margin': '4px 2px',
                            'cursor': 'pointer',
                            'borderRadius': '5px'
                        }),
                        html.Div(id='date-output'),
                        upload_component,
                        html.Img(src='https://i0.wp.com/gpapps.com/wp-content/uploads/2020/02/smart_notification_500x500.png?ssl=1', style={'height': '40px', 'width': 'auto', 'margin-right': '5px'}),
                        html.Div([
                            html.Div('Vehicle ID', style={'color': '#CC2C30', 'textAlign': 'center'}),
                            html.Div(first_row_device_id, style={'margin-top': '5px', 'textAlign': 'center'})
                        ], style={'margin': 'auto'}),
                        html.Img(src='https://banner2.cleanpng.com/20180627/txs/kisspng-volvo-b7r-ab-volvo-car-bus-commercial-vehicle-volvo-bus-5b33775ceaa317.2442862615300995489611.jpg', style={'height': '40px', 'width': 'auto', 'margin-left': '10px'}),
                        # Use upload_component as a child
                    ],
                    style={'margin-left': 'auto', 'display': 'flex', 'align-items': 'center'}
                ),
              
            ],
            style={'flex': '1', 'display': 'flex', 'align-items': 'center', 'border-bottom': '1px solid black'}
        )
    ],
    style={'flex': '0 0 auto', 'backgroundColor': 'white'}
)
# Define the modal
modal = dbc.Modal(
    [
        dbc.ModalHeader("Help"),
        dbc.ModalBody(
            html.Div([
                html.P("Choose the format to download:"),
                html.A("Download Help Text File (TXT)", href='/download/help.txt', target="_blank", style={"margin-right": "10px"}),
                html.A("Download Help Word File (DOCX)", href='/download/help.docx', target="_blank")
            ])
        ),
        dbc.ModalFooter(
            dbc.Button("Close", id="close-help-button", className="ml-auto",style={
                'backgroundColor': '#0E396B',
                'color': 'white',
                'border': 'none',
                'padding': '10px 20px',
                'textAlign': 'center',
                'textDecoration': 'none',
                'display': 'inline-block',
                'fontSize': '16px',
                'margin': '4px 2px',
                'cursor': 'pointer',
                'borderRadius': '5px'
            }),
        ),
    ],
    id="help-modal",
    is_open=False,
)

################################################ Help file download component ################################################



############################################################ Define the content of the card ##################################################
# Define the content of the card
# Function to generate cards for Card 2
def generate_card2_content():
    # Define the Diagnostic Trouble Codes table inside a card
    card_diagnostic_trouble_codes_content= html.Div(
        children=[
            html.H2('Diagnostic Trouble Codes', style={
                'color': 'black', 
                'margin-bottom': '10px',
                'font-family': 'Arial, sans-serif',  # Change font family
                'font-size': '24px'  # Change font size
            }),
            dash_table.DataTable(
                columns=[
                    {"name": "DIAGNOSTIC TROUBLE CODES", "id": "Diagnostic Trouble Codes"},
                    {"name": "", "id": "Code"}
                ],
                data=data,
                style_header={
                    'backgroundColor': '#1E5BAA',
                    'fontWeight': 'bold',
                    'color': 'white',
                    'border': '1px solid black',
                    'font-family': 'Arial, sans-serif',  # Change font family for header
                    'font-size': '16px'  # Change font size for header
                },
                style_cell={
                    'textAlign': 'left',
                    'border': '1px solid black',
                    'font-family': 'Arial, sans-serif',  # Change font family for cells
                    'font-size': '14px'  # Change font size for cells
                },
                style_cell_conditional=[
                    {
                        'if': {'column_id': 'Code'},
                        'textAlign': 'center'
                    }
                ],
                style_data_conditional=[
                    {
                        'if': {'row_index': 'odd'},
                        'backgroundColor': '#f9f9f9'
                    }
                ]
            )
        ],
        style={
            'padding': '20px',
            'backgroundColor': '#ffffff',
            'borderRadius': '20px',
            'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)',
            'margin': '10px',
            'height': 'auto',  # Allow the height to adjust based on content
            'width': '455px',  # Consistent width with the other card
            'borderWidth': '3px',
            'borderStyle': 'solid',
            'borderColor': '#6D6F71'
        }
    )
    card_predictive_maintenance_content = html.Div(
    style={'display': 'flex', 'alignItems': 'flex-start',
        'padding': '20px',
        'backgroundColor': '#ffffff',
        'borderRadius': '20px',
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)',
        'margin': '10px',
        'height': 'auto',  # Allow the height to adjust based on content
        'width': '655px',  # Consistent width with the other card
        'borderWidth': '3px',
        'borderStyle': 'solid',
        'borderColor': '#6D6F71'
    },
    children=[
        html.Div(id='output-container-pmo'),
        html.Div(
            style={'backgroundColor': '#0E396B', 'width': '200px', 'height': '300px', 'marginRight': '5px', 'display': 'flex', 'flexDirection': 'column', 'alignItems': 'center', 'justifyContent': 'center'},
            children=[
                html.Div(
                    style={'transform': 'rotate(-90deg)', 'whiteSpace': 'nowrap'},
                    children=[
                        html.H2("Predictive", style={'color': 'white', 'fontFamily': 'Times New Roman', 'fontSize': '18px', 'fontWeight': 'normal', 'fontStyle': 'normal'}),
                        html.H2("Maintenance", style={'color': 'white', 'fontFamily': 'Times New Roman', 'fontSize': '18px', 'fontWeight': 'normal', 'fontStyle': 'normal'})
                    ]
                ),
            ]
        ),
        html.Div(
            id='image-box',
            style={'backgroundColor': '#D9D9D9', 'width': '200px', 'height': '300px', 'display': 'flex', 'flexDirection': 'column', 'justifyContent': 'center', 'alignItems': 'center', 'marginRight': '5px'}
        ),
        html.Div(
            style={'backgroundColor': '#D9D9D9', 'width': '85px', 'height': '300px', 'marginRight': '5px'},
            children=[
                html.Img(src=image_src_1, style={'width': '60px', 'height': '60px', 'objectFit': 'cover', 'marginTop': '20px', 'marginRight': '10px', 'marginLeft': '10px'}),
                html.Img(src=image_src_2, style={'width': '60px', 'height': '60px', 'objectFit': 'cover', 'marginTop': '25px', 'marginRight': '10px', 'marginLeft': '10px'}),
                html.Img(src=image_src_3, style={'width': '60px', 'height': '60px', 'objectFit': 'cover', 'marginTop': '30px', 'marginRight': '10px', 'marginLeft': '10px'})
            ]
        ),
        html.Div(
            style={'backgroundColor': 'white', 'width': '100px', 'height': '300px', 'display': 'flex', 'flexDirection': 'column', 'justifyContent': 'flex-start', 'alignItems': 'center'},
            children=[
                html.Div("One PM is Overdue", style={'fontFamily': 'Times New Roman', 'fontSize': '20px', 'fontStyle': 'italic', 'color': 'black', 'marginTop': '10px'}),
                html.Div("At least PM in next 24hrs", style={'fontFamily': 'Times New Roman', 'fontSize': '20px', 'fontStyle': 'italic', 'color': 'black', 'marginTop': '30px'}),
                html.Div("No PMS in next 48hrs", style={'fontFamily': 'Times New Roman', 'fontSize': '20px', 'fontStyle': 'italic', 'color': 'black', 'marginTop': '30px'})
            ]
        )
    ]

)

    # Card 2
    card2_content = dbc.Container([
     dbc.Row([
        dbc.Col([
            html.H1("Battery Runtime calculated uptill Date ", style={'color': 'black'}),
            dcc.Graph(id='live-update-graph'),
            dcc.Interval(
                id='interval-component',
                interval=1*1000,  # in milliseconds
                n_intervals=0
            )
        ], width=12)
    ]),
    dbc.Row([
        dbc.Col([
            html.Div(id='output-data-clock')
        ])
    ])
    ], style={'padding': '20px', 'backgroundColor': '#ffffff', 'borderRadius': '20px', 'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 'margin': '10px', 'height':'455px','width':'455px', 'borderColor': '##6D6F71','border': '2px solid'})


    # Card 3
    card3_content = html.Div(
        children=[
            html.H2('Card 3 Title', style={'color': 'green'}),
            html.P('This is some text inside Card 3.', style={'fontStyle': 'italic'}),
            html.Div("Card 3 Content")
        ],
        style={'padding': '20px', 'backgroundColor': '#D9D9D9', 'borderRadius': '20px', 'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 'margin': '10px', 'height':'250px', 'width':'50%'}
    )

    # Spacer after Card 3
    spacer3 = html.Div(style={'height': '5px'})

    # Card 4
    card4_content = html.Div(
        children=[
            #html.H2('Card 4 Title', style={'color': 'green'}),
            #html.P('This is some text inside Card 4.', style={'fontStyle': 'italic'}),
            #html.Div("Card 4 Content")
        ],
        style={'padding': '20px', 'backgroundColor': '#D9D9D9', 'borderRadius': '20px', 'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 'margin': '10px', 'height':'150px', 'width':'50%'}
    )

    # Card 5
    # Card 5
    card5_content = html.Div(
        children=[
            html.H2('Coolant Temperature', style={'color': 'black'}),
            html.P('It is important to maintain safety and increase vehicle life for more infoe go to help', style={'fontStyle': 'italic'}),
            html.Div([
                html.Img(id='gauge-chart', style={
                    'width': '100%', 
                    'height': '350px', 
                    'maxWidth': '100%', 
                    'maxHeight': '100%', 
                    'objectFit': 'cover', 
                    'objectPosition': 'center',
                    'clipPath': 'inset(0% 0% 40% 0%)'  # Adjust the bottom percentage to crop more or less
                })
            ])
        ],
        style={
           'padding': '20px', 
           'backgroundColor': '#ffffff', 
           'borderRadius': '20px', 
           'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
           'margin': '10px', 
           'height': '350px', 
           'width': '455px', 
           'borderWidth': '3px',  # Set the border width
           'borderStyle': 'solid',  # Set the border style
           'borderColor': '#6D6F71'  # Set the border color separately
       }    )

    # Card 6
    card6_content = html.Div(
        children=[
            html.H2('DC/DC Temperature', style={'color': 'black'}),
            html.P('DC/DC is used to convert the high voltage to lower voltage for more details go to help', style={'fontStyle': 'italic'}),
            html.Div([
                html.Img(id='my-gauge-chart', style={
                    'width': '100%', 
                    'height': '350px', 
                    'maxWidth': '100%', 
                    'maxHeight': '100%', 
                    'objectFit': 'cover', 
                    'objectPosition': 'center',
                    'clipPath': 'inset(0% 0% 40% 0%)'  # Adjust the bottom percentage to crop more or less
                })
            ])
        ],
        style={
           'padding': '20px', 
           'backgroundColor': '#ffffff', 
           'borderRadius': '20px', 
           'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
           'margin': '10px', 
           'height': '350px', 
           'width': '455px', 
           'borderWidth': '3px',  # Set the border width
           'borderStyle': 'solid',  # Set the border style
           'borderColor': '#6D6F71'  # Set the border color separately
       }    )
    #card7
    card7_content = html.Div(
        children=[
            html.H2('Cell Temperature', style={'color': 'black'}),
            html.P('Excessive heat can lead to a condition known as thermal runaway for more info go to help', style={'fontStyle': 'italic'}),
            html.Div([
                html.Img(id='gauge-chart-cell', style={
                    'width': '100%', 
                    'height': '350px', 
                    'maxWidth': '100%', 
                    'maxHeight': '100%', 
                    'objectFit': 'cover', 
                    'objectPosition': 'center',
                    'clipPath': 'inset(0% 0% 40% 0%)'  # Adjust the bottom percentage to crop more or less
                })
            ])
        ],
        style={
           'padding': '20px', 
           'backgroundColor': '#ffffff', 
           'borderRadius': '20px', 
           'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
           'margin': '10px', 
           'height': '350px', 
           'width': '455px', 
           'borderWidth': '3px',  # Set the border width
           'borderStyle': 'solid',  # Set the border style
           'borderColor': '#6D6F71'  # Set the border color separately
       }    )
      #card8
    card8_content = html.Div(
        children=[
            html.H2('Energy Production', style={'color': 'black'}),
            html.Button('Show Regeneration Power', id='regeneration-button', n_clicks=0,style={'fontSize': 21}),
            html.Button('Show Battery Energy Consumed', id='battery-button', n_clicks=0,style={'fontSize': 21}),
            dcc.Graph(id='line-chart')
        ],
        style={
            'padding': '20px', 
            'backgroundColor': '#ffffff', 
            'borderRadius': '20px', 
            'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
            'margin': '10px', 
            'height': '600px', 
            'width': '700px', 
            'borderWidth': '3px',  # Set the border width
            'borderStyle': 'solid',  # Set the border style
            'borderColor': '#6D6F71'  # Set the border color separately
        }
    )
    card11_content = html.Div(
        children=[
            html.H2("Energy Consumption", style={'color': 'black'}),
            html.Button('Motor Energy', id='motor-button', n_clicks=0, style={'fontSize': 21}),
           html.Button('HVAC Energy', id='hvac-button', n_clicks=0, style={'fontSize': 21}),
            dcc.Graph(id='energy-graph')
        ],
        style={
            'padding': '20px', 
            'backgroundColor': '#ffffff', 
            'borderRadius': '20px', 
            'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
            'margin': '10px', 
            'height': '600px', 
            'width': '700px', 
            'borderWidth': '3px',  # Set the border width
            'borderStyle': 'solid',  # Set the border style
            'borderColor': '#6D6F71'  # Set the border color separately
        }
    )
    card9_content = html.Div(
        children=[
            html.H2('Maintenance Centre and Analysed Route MAP', style={'color': 'black'}),
            html.Div([
                dcc.Graph(
                    id='map-plot',
                    style={'height': '600px'}  # Adjust the height and width here
                )
            ])
        ],
        style={
            'padding': '20px',
            'backgroundColor': '#ffffff',
            'borderRadius': '20px',
            'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)',
            'margin': '10px',
            'height': '700px',  # This height is for the whole card
            'width': '1400px',    # This width is for the whole card
            'borderWidth': '3px',  
            'borderStyle': 'solid',
            'borderColor': '#6D6F71'
        }
    )
    #card7
    cardmotorcurrentemp_content = html.Div(
        children=[
            html.H2('Motor Current', style={'color': 'black'}),
            html.P('High motor current can cause voltage drops in the electrical supply system, affecting the performance of other equipment connected to the same power source', style={'fontStyle': 'italic'}),
            html.Div([
                html.Img(id='gauge-chart-motor', style={
                    'width': '100%', 
                    'height': '350px', 
                    'maxWidth': '100%', 
                    'maxHeight': '100%', 
                    'objectFit': 'cover', 
                    'objectPosition': 'center',
                    'clipPath': 'inset(0% 0% 40% 0%)'  # Adjust the bottom percentage to crop more or less
                })
            ])
        ],
        style={
           'padding': '20px', 
           'backgroundColor': '#ffffff', 
           'borderRadius': '20px', 
           'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
           'margin': '10px', 
           'height': '450px', 
           'width': '455px', 
           'borderWidth': '3px',  # Set the border width
           'borderStyle': 'solid',  # Set the border style
           'borderColor': '#6D6F71'  # Set the border color separately
       }    )
    #card7
    cardmotortemp_content = html.Div(
        children=[
            html.H2('Power Dissipation', style={'color': 'black'}),
            html.P('Power dissipation refers to the process by which an electrical or electronic device converts electrical energy into heat.For more info go to help.', style={'fontStyle': 'italic'}),
            html.Div([
                html.Img(id='black-odometer', style={
                    'width': '100%', 
                    'height': '350px', 
                    'maxWidth': '100%', 
                    'maxHeight': '100%', 
                    'objectFit': 'cover', 
                    'objectPosition': 'center',
                    'clipPath': 'inset(19% 15% 15% 19%)'  # Adjust the bottom percentage to crop more or less
                })
            ])
        ],
        style={
           'padding': '20px', 
           'backgroundColor': '#ffffff', 
           'borderRadius': '20px', 
           'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
           'margin': '10px', 
           'height': '450px', 
           'width': '455px', 
           'borderWidth': '3px',  # Set the border width
           'borderStyle': 'solid',  # Set the border style
           'borderColor': '#6D6F71'  # Set the border color separately
       }    )#card8
    #card7
    cardmotorhealth_content = html.Div(
    children=[
        html.H2('Motor Health Score', style={'color': 'black', 'margin-bottom': '10px'}),
        html.P('Please note that there might not be any change in the pie chart for short duration as it is calculated on the basis of score', style={'fontStyle': 'italic', 'margin-bottom': '10px'}),
        html.Div([
            
            html.Div(id='output-container'),
            html.Div(id='circle-chart-container', children=[
                html.Div(id='circle-chart', style={'position': 'relative', 
                                                   'width': '50px',
                                                   'height': '50px'  # Adjust the bottom
                                                   })
            ])
            
        ])
    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '450px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
     
    #card7
    cardoperatingrate_content= html.Div(
    children=[
        html.H2('Operational Performance', style={'color': 'black', 'margin-bottom': '10px'}),
        #html.P('Please note that there might not be any change in the pie chart for short duration as it is calculated on the basis of score', style={'fontStyle': 'italic', 'margin-bottom': '10px'}),
        html.Div(id='operational-rate-pie'),
        html.Div([
            #html.H2("Activity Time:"),
            html.H3(id='activity-time-output')
        ]),
        dcc.Graph(id='pie-chart')
    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '450px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    #card7
    cardhealthscore_content= html.Div(
    children=[
        html.H2('Vehicle Health Score', style={'color': 'black', 'margin-bottom': '10px'}),
        #html.P('Please note that there might not be any change in the pie chart for short duration as it is calculated on the basis of score', style={'fontStyle': 'italic', 'margin-bottom': '10px'}),
       html.Div([
           html.Div(id='output-container-date-picker-range3'),
           dcc.Graph(id='health-score-doughnut')
       ])
        
    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '450px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    #card8
    cardmotorefficiency_content = html.Div(
      children=[
          html.H2('Motor Efficiency', style={'color': 'black'}),
          html.P('A negative value can indicate that the system is consuming power rather than generating it. This occurs when the vehicle is accelerating or maintaining speed, where energy is being drawn from the battery to power the electric motor',style={'fontStyle': 'italic'}),
          #html.Button('Show Regeneration Power', id='regeneration-button', n_clicks=0,style={'fontSize': 21}),
          #html.Button('Show Battery Energy Consumed', id='battery-button', n_clicks=0,style={'fontSize': 21}),
          dcc.Graph(id='efficiency-graph')
      ],
      style={
          'padding': '20px', 
          'backgroundColor': '#ffffff', 
          'borderRadius': '20px', 
          'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
          'margin': '10px', 
          'height': '600px', 
          'width': '950px', 
          'borderWidth': '3px',  # Set the border width
          'borderStyle': 'solid',  # Set the border style
          'borderColor': '#6D6F71'  # Set the border color separately
      }
  )


    cardmotorinfo_content = html.Div(
    children=[
        html.H2('Motor Health Information', style={'color': 'black', 'margin-bottom': '10px'}),
        html.P('Below are basic variables tha t are used for motor health calculation and we have used them to calculate the average motor health score.These are only some if in case you require more information we would suggest you to go to help. ', style={'fontStyle': 'italic', 'margin-bottom': '10px', 'color': 'blue', 'font-weight': 'bold', 'font-size': '20px'}
),
        html.Div([
            
            html.Div(id='output-container2'),
            
            
        ])
    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '600px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    
    carddistanceinfo_content = html.Div(
    children=[
        html.H2('Vehicle Distance Information', style={'color': 'black', 'margin-bottom': '9px'}),
       # html.P('Below are basic variables tha t are used for motor health calculation and we have used them to calculate the average motor health score.These are only some if in case you require more information we would suggest you to go to help. ', style={'fontStyle': 'italic', 'margin-bottom': '10px', 'color': 'blue', 'font-weight': 'bold', 'font-size': '20px'}),
        html.Div([
            
            html.Div(id='output-container-distance-info')
            
            
        ])
    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '200px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    cardvehiclerating_content = html.Div(
    children=[
        html.H2('Vehicle Rating', style={'color': 'black', 'margin-bottom': '10px'}),
       # html.P('Below are basic variables tha t are used for motor health calculation and we have used them to calculate the average motor health score.These are only some if in case you require more information we would suggest you to go to help. ', style={'fontStyle': 'italic', 'margin-bottom': '10px', 'color': 'blue', 'font-weight': 'bold', 'font-size': '20px'}),
        html.Div([
            
            html.Div(id='output-container-vehicle-rating')
            
            
        ])
    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '200px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    #card8
    cardvehicleinfo_content = html.Div(
      children=[
          html.H2('Vehicle Information', style={'color': 'black'}),
          #html.P('A negative value can indicate that the system is consuming power rather than generating it. This occurs when the vehicle is accelerating or maintaining speed, where energy is being drawn from the battery to power the electric motor',style={'fontStyle': 'italic'}),
          #html.Button('Show Regeneration Power', id='regeneration-button', n_clicks=0,style={'fontSize': 21}),
          #html.Button('Show Battery Energy Consumed', id='battery-button', n_clicks=0,style={'fontSize': 21}),
          html.Div(id='safety-status',style={'fontSize': '20px', 'fontStyle': 'italic', 'fontWeight': 'normal'}),
          html.Div(id='internal-temp-display',style={'fontSize': '20px', 'fontStyle': 'italic', 'fontWeight': 'normal'}),
          html.Div(id='vehicle-body-temp-display',style={'fontSize': '20px', 'fontStyle': 'italic', 'fontWeight': 'normal'}),
          html.Div(id='soc-display',style={'fontSize': '20px', 'fontStyle': 'italic', 'fontWeight': 'normal'})

      ],
      style={
          'padding': '20px', 
          'backgroundColor': '#ffffff', 
          'borderRadius': '20px', 
          'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
          'margin': '10px', 
          'height': 'auto', 
          'width': '250px', 
          'borderWidth': '3px',  # Set the border width
          'borderStyle': 'solid',  # Set the border style
          'borderColor': '#6D6F71'  # Set the border color separately
      }
  )
    
    cardcellstate_content = html.Div(
    children=[
        html.H2('Cell Health Overview', style={'color': 'black', 'margin-bottom': '10px'}),
        html.P('This is a breif overview about the cell.These are some important parameters for cell safety marked on a scale of 100 to avoid confusion for more info go to help.', style={'fontStyle': 'italic', 'margin-bottom': '10px', 'color': 'black', 'font-size': '20px'}),
        html.Div([
            html.Div([
                #html.H4("State of Charge (SOC)", style={'margin': '5px 0'}),
                dcc.Graph(id='soc-gauge')
            ], style={'margin-bottom': '10px'}),
            html.Div([
                #html.H4("Average Max Cell Temperature", style={'margin': '5px 0'}),
                dcc.Graph(id='avg-max-temp-gauge')
            ], style={'margin-bottom': '10px'}),
            html.Div([
                #html.H4("Average Min Cell Temperature", style={'margin': '5px 0'}),
                dcc.Graph(id='avg-min-temp-gauge')
            ], style={'margin-bottom': '10px'})
        ], style={'display': 'flex', 'flexDirection': 'column', 'alignItems': 'center'}),
        html.Div(id='avg-soc-hidden', style={'display': 'none'})  # Hidden div to store average SOC value

    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '455px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    cardcellinfo_content = html.Div(
    children=[
        html.H2('Cell  Overview', style={'color': 'black', 'margin-bottom': '10px'}),
        html.P('Cell health in an electric vehicle (EV) refers to the condition and performance of the individual battery cells that make up the vehicles battery pack. Maintaining cell health is crucial because it directly impacts the vehicles range, efficiency, and overall lifespan. Poor cell health can lead to reduced performance, shorter driving range, and increased risk of battery failure. It is particularly important in EV applications like traction batteries, which power the vehicle, and auxiliary batteries, which support secondary systems.', 
               style={'fontStyle': 'italic', 'margin-bottom': '10px', 'color': 'blue', 'font-size': '20px'}),
           ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '455px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    cardcellscore_content = html.Div(
    children=[
        html.H2('Cell Health Score', style={'color': 'black', 'margin-bottom': '10px'}),
        html.P('Eell health score on a composite scoring of parameters including cell temp,volatge & state of charge of the cell. For more info refere help. ', style={'fontStyle': 'italic', 'margin-bottom': '10px', 'color': 'black', 'font-size': '20px'}),
        dcc.Graph(id='health-score-pie-chart')

    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '455px',  # Increase the height to accommodate all content
        'width': '455px',  # Increase the width to better fit the content
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    cardwarnings_content = html.Div(
        style={
            'padding': '20px', 
            'backgroundColor': '#ffffff', 
            'borderRadius': '20px', 
            'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
            'margin': '10px', 
            'height': '455px',  # Increase the height to accommodate all content
            'width': '455px',  # Increase the width to better fit the content
            'borderWidth': '3px',  # Set the border width
            'borderStyle': 'solid',  # Set the border style
            'borderColor': '#6D6F71'  # Set the border color separately
        },
        children=[
            # Header
            html.Div(
                style={'backgroundColor': '#1D6DCE', 'padding': '10px', 'textAlign': 'center', 'color': 'white', 'fontWeight': 'bold'},
                children=html.H3("ARMF WARNING SYSTEMS")
            ),
            # Warning systems
            html.Div(
                style={'padding': '10px'},
                children=[
                    dbc.Row([
                        dbc.Col(html.I(className="bi bi-bell-fill", style={'color': '#1D6DCE', 'fontSize': '24px'}), width="auto"),
                        dbc.Col("AMBER WARNING SYSTEM", style={'fontWeight': 'bold'}),
                        dbc.Col("RED", style={'color': 'red', 'fontWeight': 'bold'}),
                    ], align="center"),
                    dbc.Row([
                        dbc.Col(html.I(className="bi bi-bell-fill", style={'color': '#1D6DCE', 'fontSize': '24px'}), width="auto"),
                        dbc.Col("RED STOP LAMP", style={'fontWeight': 'bold'}),
                        dbc.Col("GREEN", style={'color': 'green', 'fontWeight': 'bold'}),
                    ], align="center"),
                    dbc.Row([
                        dbc.Col(html.I(className="bi bi-bell-fill", style={'color': '#1D6DCE', 'fontSize': '24px'}), width="auto"),
                        dbc.Col("MALFUNCTION LAMP", style={'fontWeight': 'bold'}),
                        dbc.Col("GREEN", style={'color': 'green', 'fontWeight': 'bold'}),
                    ], align="center"),
                    dbc.Row([
                        dbc.Col(html.I(className="bi bi-bell-fill", style={'color': '#1D6DCE', 'fontSize': '24px'}), width="auto"),
                        dbc.Col("FLASH MALFUNCTION LAMP", style={'fontWeight': 'bold'}),
                        dbc.Col("GREEN", style={'color': 'green', 'fontWeight': 'bold'}),
                    ], align="center"),
                ]
            )
        ]
    )
    #card8
    cardcellcycle_content = html.Div(
      children=[
          html.H2('Cell Charge and Discharge Cycle', style={'color': 'black'}),
          html.Button('Charging Graph', id='charging-button', n_clicks=0, style={'marginRight': '10px', 'background-color': '#0E396B', 'color': 'white', 'fontSize': '18px', 'padding': '10px 20px'}),
          html.Button('Discharging Graph', id='discharging-button', n_clicks=0, style={'background-color': '#0E396B', 'color': 'white', 'fontSize': '18px', 'padding': '10px 20px'}),
          dcc.Graph(id='cycle-graph')
      ],
      
      style={
          'padding': '20px', 
          'backgroundColor': '#ffffff', 
          'borderRadius': '20px', 
          'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
          'margin': '10px', 
          'height': '600px', 
          'width': '900px', 
          'borderWidth': '3px',  # Set the border width
          'borderStyle': 'solid',  # Set the border style
          'borderColor': '#6D6F71'  # Set the border color separately
      }
  )
    #card8
    cardcellcombine_content = html.Div(
      children=[
          html.H2('Cell Statistics', style={'color': 'black'}),
          #html.Button('Charging Graph', id='charging-button', n_clicks=0, style={'marginRight': '10px', 'background-color': '#0E396B', 'color': 'white', 'fontSize': '18px', 'padding': '10px 20px'}),
          #html.Button('Discharging Graph', id='discharging-button', n_clicks=0, style={'background-color': '#0E396B', 'color': 'white', 'fontSize': '18px', 'padding': '10px 20px'}),
          dcc.Graph(id='combined-doughnut-chart')
      ],
      
      style={
          'padding': '20px', 
          'backgroundColor': '#ffffff', 
          'borderRadius': '20px', 
          'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
          'margin': '10px', 
          'height': '600px', 
          'width': '505px', 
          'borderWidth': '3px',  # Set the border width
          'borderStyle': 'solid',  # Set the border style
          'borderColor': '#6D6F71'  # Set the border color separately
      }
  )
    cardspeed_content = html.Div(
    children=[
        html.H2('Average Speed of Vehicle', style={'color': 'black', 'margin-bottom': '10px'}),
        #html.P('Below are basic variables tha t are used for motor health calculation and we have used them to calculate the average motor health score.These are only some if in case you require more information we would suggest you to go to help. ', style={'fontStyle': 'italic', 'margin-bottom': '10px', 'color': 'blue', 'font-weight': 'bold', 'font-size': '20px'}),
        html.Div([            
            html.Img(id='gauge-chart-speed'),
                      
        ], style={'display': 'flex', 
                  'justifyContent': 'center', 
                  'alignItems': 'center', 
                  'height': '350px',
                  'width':'200',
                  'clipPath': 'inset(10% 10% 10% 10%)'})  # Center the image using flexbox
    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '455px', 
        'width': '455px', 
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    } 
)
    cardSOH_content = html.Div(
    children=[
        html.H2('State Of Health', style={'color': 'black', 'margin-bottom': '10px'}),
        dbc.Row([
            dbc.Col([
                html.Div(id='output-data')
            ])
        ]),
        dbc.Row([
            dbc.Col(
                html.Div(
                    children=[
                        dcc.Graph(
                            id='soh-battery',
                            config={'displayModeBar': False},
                            figure=fig,
                            style={'height': '300px', 'width': '350px'}  # Adjust the height and width here
                        ),
                        html.Div(
                            id='battery-text',
                            style={'textAlign': 'center', 'marginTop': '20px'}
                        )
                    ],
                    style={'display': 'flex', 'flexDirection': 'column', 'alignItems': 'center'}
                ),
                width={'size': 6, 'offset': 3},
                style={'display': 'flex', 'justifyContent': 'center'}
            )
        ])
    ],
    style={
        'padding': '20px', 
        'backgroundColor': '#ffffff', 
        'borderRadius': '20px', 
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
        'margin': '10px', 
        'height': '455px', 
        'width': '455px', 
        'borderWidth': '3px',  # Set the border width
        'borderStyle': 'solid',  # Set the border style
        'borderColor': '#6D6F71'  # Set the border color separately
    }
)

    
    cardbattpred_content = html.Div(
        children=[
            html.H2("Predicted distance travelled", style={'color': 'black'}),
            html.P('Predicition are based on very less hence it can be inaccurate. AutoArima forecasting model has been used alogn post normalization and stationary analysis tests.', style={'fontStyle': 'italic', 'margin-bottom': '10px', 'color': 'black', 'font-size': '20px'}),
            #html.Button('Motor Energy', id='motor-button', n_clicks=0, style={'fontSize': 21}),
           #html.Button('HVAC Energy', id='hvac-button', n_clicks=0, style={'fontSize': 21}),
            html.Div([
                dcc.Graph(
                    id='forecast-plot',
                    figure=fig
                )
            ])
        ],
        style={
            'padding': '20px', 
            'backgroundColor': '#ffffff', 
            'borderRadius': '20px', 
            'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
            'margin': '10px', 
            'height': '600px', 
            'width': '910px', 
            'borderWidth': '3px',  # Set the border width
            'borderStyle': 'solid',  # Set the border style
            'borderColor': '#6D6F71'  # Set the border color separately
        }
    )
    #card7
    cardbatterydeg_content = html.Div(
        children=[
            html.H2('Battery Degradation', style={'color': 'black'}),
            #html.P('High motor current can cause voltage drops in the electrical supply system, affecting the performance of other equipment connected to the same power source', style={'fontStyle': 'italic'}),
            html.Div(id='output-container-date-picker-range'),
            html.Div([
                html.Img(id='gauge-chart-degrade', style={
                    'width': '100%', 
                    'height': '325px', 
                    'maxWidth': '100%', 
                    'maxHeight': '100%', 
                    'objectFit': 'cover', 
                    'objectPosition': 'center',
                    'clipPath': 'inset(0% 0% 40% 0%)'  # Adjust the bottom percentage to crop more or less
                })
            ])
        ],
        style={
           'padding': '20px', 
           'backgroundColor': '#ffffff', 
           'borderRadius': '20px', 
           'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
           'margin': '10px', 
           'height': '300px', 
           'width': '455px', 
           'borderWidth': '3px',  # Set the border width
           'borderStyle': 'solid',  # Set the border style
           'borderColor': '#6D6F71'  # Set the border color separately
       }    )
    # Define the ARIMA Forecasting content inside a card
    arima_forecasting_content = html.Div(
    children=[
        html.H3('ARIMA Forecasting'),
        #html.Div(f'Mean Squared Error for Motor Power: {mean_squared_error(test_motor, motor_model_fit.forecast(steps=len(test_motor)))}'),
        dcc.Tabs(id='tabs', value='motor_power', children=[
            dcc.Tab(label='Motor Power', value='motor_power', style={'font-size': '12px','padding': '5px', 'margin': '0px'}),  # Decrease font size
            dcc.Tab(label='Cell Max Temp', value='cell_max_temp', style={'font-size': '12px','padding': '5px', 'margin': '0px'}),  # Decrease font size
            dcc.Tab(label='Battery Prediction', value='battery_prediction', style={'font-size': '12px','padding': '5px', 'margin': '0px'})  # Decrease font size
        ]),
        dcc.Graph(id='forecast-plot')
    ],
    style={
        'padding': '20px',
        'backgroundColor': '#ffffff',
        'borderRadius': '20px',
        'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)',
        'margin': '10px',
        'height': '470px',  # Allow the height to adjust based on content
        'width': '910px',  # Consistent width with the other card
        'borderWidth': '3px',
        'borderStyle': 'solid',
        'borderColor': '#6D6F71'
    }
)
    #card7
    cardbatteryinfo_content = html.Div(
        children=[
            html.H2('Battery Information', style={'color': 'black'}),
            #html.P('High motor current can cause voltage drops in the electrical supply system, affecting the performance of other equipment connected to the same power source', style={'fontStyle': 'italic'}),
        dbc.Container([
             dbc.Row([
                dbc.Col([
                    #html.H3("Discharge Current Results"),
                    html.Div(id='output-data2')
                ])
            ])
        ])
        ],
        style={
           'padding': '20px', 
           'backgroundColor': '#ffffff', 
           'borderRadius': '20px', 
           'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
           'margin': '10px', 
           'height': '270px', 
           'width': '455px', 
           'borderWidth': '3px',  # Set the border width
           'borderStyle': 'solid',  # Set the border style
           'borderColor': '#6D6F71'  # Set the border color separately
       }    )
                  
  
    return card2_content, card3_content, spacer3, card4_content, card5_content,card6_content,card7_content,card8_content,card9_content,card11_content,cardmotorcurrentemp_content,cardmotortemp_content,cardmotorhealth_content,cardmotorefficiency_content,cardmotorinfo_content, cardcellstate_content,cardcellinfo_content,cardcellscore_content,cardcellcycle_content,cardcellcombine_content,cardspeed_content,cardSOH_content,cardbattpred_content,cardbatterydeg_content,cardbatteryinfo_content,arima_forecasting_content,card_diagnostic_trouble_codes_content,cardvehicleinfo_content,cardoperatingrate_content,carddistanceinfo_content,cardhealthscore_content,cardvehiclerating_content,card_predictive_maintenance_content,cardwarnings_content


# Create cards
card1 = html.Div(
    id='card-1',
    children=[
        html.Div(
            children=[
                html.H2('Select Date', style={'color': 'black'}),Date1
                 ],
            style={
                'padding': '20px', 
                'backgroundColor': '#ffffff', 
                'borderRadius': '20px', 
                'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
                'margin': '10px', 
                'height': '150px', 
                'width': '697px', 
                'borderWidth': '3px',  # Set the border width
                'borderStyle': 'solid',  # Set the border style
                'borderColor': '#6D6F71'  # Set the border color separately
            }        ),
        #elongated_rectangle
        
    ],
    
)

card10 = html.Div(
    id='card-10',
    children=[
        html.Div(
            children=[
                html.H2('Select Date for time based garphs', style={'color': 'black'}),Date2
                 ],
           style={
               'padding': '20px', 
               'backgroundColor': '#ffffff', 
               'borderRadius': '20px', 
               'boxShadow': '0px 0px 10px 0px rgba(0,0,0,0.1)', 
               'margin': '10px', 
               'height': '150px', 
               'width': '697px', 
               'borderWidth': '3px',  # Set the border width
               'borderStyle': 'solid',  # Set the border style
               'borderColor': '#6D6F71'  # Set the border color separately
           }       ),
        #elongated_rectangle
        
    ],
    
)
card2, card3, spacer3, card4, card5,card6,card7,card8,card9,card11,cardmotorcurrentemp,cardmotortemp,cardmotorhealth,cardmotorefficiency,cardmotorinfo,cardcellstate,cardcellinfo,cardcellscore,cardcellcycle,cardcellcombine,cardspeed,cardSOH,cardbattpred,cardbatterydeg,cardbatteryinfo,arima_forecasting,card_diagnostic_trouble_codes,cardvehicleinfo,cardoperatingrate,carddistanceinfo,cardhealthscore,cardvehiclerating,card_predictive_maintenance,cardwarnings= generate_card2_content()


# App layout
# Integrate file upload component into your existing layout
# Define the app layout
# App layout
# Integrate file upload component into your existing layout
# Define the app layout
app.layout = html.Div(
    children=[
        navbar, # Add your other layout components here# Assuming navbar is defined elsewhere
        modal,
           html.Div(
            children=[
                sidebar,  # Assuming sidebar is defined elsewhere
                html.Div(
                    id='page-content',
                    children=[
                        dcc.DatePickerRange(
                            id='date-picker-range',
                            display_format='Y-M-D',
                            start_date_placeholder_text="Start Date",
                            end_date_placeholder_text="End Date"
                        ),
                        html.Div(id='card5_content'),  # Placeholder for card5 content
                        html.Div(id='card6_content'),
                        html.Div(id='card7_content'),
                        html.Div(id='card8_content'),
                        html.Div(id='card11_content'),
                        dcc.DatePickerRange(
                            id='date-picker-range2',
                            start_date=df['eDate'].min().date(),
                            end_date=df['eDate'].max().date(),
                            display_format='YYYY-MM-DD',
                        ),
                        html.Div(id='card9_content'),
                        html.Div(id='cardmotorcurrentemp_content'),
                        html.Div(id='cardmotortemp_content'),
                        html.Div(id='cardmotorhealth_content'),
                        html.Div(id='cardmotorefficiency_content'),
                        html.Div(id='cardmotorinfo_content'),
                        html.Div(id='cardcellstate_content'),
                        html.Div(id='cardcellinfo_content'),
                        html.Div(id='cardcellscore_content'),
                        html.Div(id='cardcellcycle_content'),
                        html.Div(id='cardcellcombine_content'),
                        html.Div(id='cardspeed_content'),
                        html.Div(id='cardSOH_content'),
                        html.Div(id='cardbattpred_content'),
                        html.Div(id='cardbatterydeg_content'),
                        html.Div(id='cardbatteryinfo_content'),
                        html.Div(id='arima_forecasting_content'),
                        html.Div(id='card_diagnostic_trouble_codes_content'),
                        html.Div(id='cardvehicleinfo_content'),
                        html.Div(id='cardoperatingrate_content'),
                        html.Div(id='carddistanceinfo_content'),
                        html.Div(id='cardhealthscore_content'),
                        html.Div(id='cardvehiclerating_content'),
                        html.Div(id='card_predictive_maintenance_content'),
                        html.Div(id='cardwarnings_content')
                        
                        
                        # No need to add the Help button here again
                    ],
                    style={'flex': '1'}  # Adjust flex for output component
                ),
            ],
            style={'display': 'flex'}
        )
    ]
)


##################################################Defining all the callbacks#########################################################################
# Callback to switch pages
# Callback to card5 for coolant temp:
@app.callback(
        Output('health-score-pie-chart', 'figure'),
        [Input('date-picker-range2', 'start_date'),
         Input('date-picker-range2', 'end_date')]
    )
def update_pie_chart(start_date, end_date):
        filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]
        
        # Apply additional condition
        filtered_df = filtered_df[(filtered_df['Charging Status'] == 0) & (filtered_df['vehicleSpeed'] != 0)]

        # Calculate mean values for Max and Min cell voltage
        mean_max_cell_v = filtered_df['Max_Cell_V'].mean()
        mean_min_cell_v = filtered_df['Min_Cell_V'].mean()

        # Calculate scores for Max and Min cell voltage
        max_cell_v_score = calculate_voltage_score(mean_max_cell_v, max_cell_v_thresholds)
        min_cell_v_score = calculate_voltage_score(mean_min_cell_v, min_cell_v_thresholds)

        # Calculate mean values for Max and Min cell temperature
        mean_max_cell_temp = filtered_df['Max_Cell_Temp'].mean()
        mean_min_cell_temp = filtered_df['Min_Cell_Temp'].mean()

        # Calculate scores for Max and Min cell temperature
        max_cell_temp_score = calculate_temperature_score(mean_max_cell_temp, max_cell_temp_thresholds)
        min_cell_temp_score = calculate_temperature_score(mean_min_cell_temp, min_cell_temp_thresholds)

        # Calculate final health score
        final_health_score = max_cell_v_score + min_cell_v_score + max_cell_temp_score + min_cell_temp_score

        # Create pie chart with thinner segments and smaller size
        pie_chart = go.Figure(
            data=[go.Pie(
                labels=['Health Score', 'Remaining'],
                values=[final_health_score, 360 - final_health_score],
                marker=dict(colors=['green', 'red']),
                hole=.6  # Increase hole size to make segments thinner
            )]
        )
        pie_chart.update_layout(
            #title='Battery Health Score Pie Chart',
            height=250,width=400, margin=dict(l=20, r=20, t=10, b=20)
        )

        return pie_chart
# Callback to open the help modal
@app.callback(
    Output("help-modal", "is_open"),
    [Input("open-help-button", "n_clicks"), Input("close-help-button", "n_clicks")],
    [dash.dependencies.State("help-modal", "is_open")],
)
def toggle_modal(open_clicks, close_clicks, is_open):
    if open_clicks or close_clicks:
        return not is_open
    return is_open

# Serve the files
@app.server.route('/download/<path:path>')
def serve_static(path):
    if path.endswith('.txt'):
        return flask.send_from_directory(current_directory, path)
    elif path.endswith('.docx'):
        return flask.send_from_directory(current_directory, path)
    else:
        return "Unsupported file format."
    
# Callback to update the gauge chart based on the selected date range
@app.callback(
    Output('gauge-chart', 'src'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date')
)
def update_gauge_chart(start_date, end_date):
    if start_date is not None and end_date is not None:
        # Filter the data based on the selected date range
        mask = (df['cdate'] >= start_date) & (df['cdate'] <= end_date)
        filtered_df = df.loc[mask]

        # Calculate the average coolant temperature
        average_coolant_temp = filtered_df['engineCoolantTemp'].mean()

        # Create the gauge chart
        encoded_image = create_gauge_chart(colors, values, average_coolant_temp)

        # Return the image source for the Img component
        return f"data:image/png;base64,{encoded_image}"
    else:
        return f"data:image/png;base64,{initial_encoded_image}"
   
# Callback to update the gauge chart based on the selected date range
@app.callback(
    Output('my-gauge-chart', 'src'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date')
)
def update_my_gauge_chart(start_date, end_date):
    if start_date is not None and end_date is not None:
        # Filter the data based on the selected date range
        mask = (df['cdate'] >= start_date) & (df['cdate'] <= end_date)
        filtered_df = df.loc[mask]

        # Calculate the DC/DC temperature for the filtered data
        dcdc_temp = calculate_dcdc_temp(
            filtered_df['Max_Cell_Temp'].mean(),
            filtered_df['Min_Cell_Temp'].mean(),
            filtered_df['Charging_Current'].mean(),
            filtered_df['MotorCurrent'].mean()
        )

        # Create the gauge chart
        encoded_image = create_gauge_chart1(colors, values, dcdc_temp)

        # Return the image source for the Img component
        return f"data:image/png;base64,{encoded_image}"
    else:
        return ""
    
    
# Callback to update the gauge chart based on the selected date range
@app.callback(
    Output('gauge-chart-cell', 'src'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date')
)
def update_gauge_chart(start_date, end_date):
    if start_date is not None and end_date is not None:
        # Filter the data based on the selected date range
        mask = (df['cdate'] >= start_date) & (df['cdate'] <= end_date)
        filtered_df = df.loc[mask]

        # Calculate the average cell temperature
        average_cell_temp = (filtered_df['Max_Cell_Temp'].mean() + filtered_df['Min_Cell_Temp'].mean()) / 2

        # Create the gauge chart
        encoded_image = create_gauge_chart_cell(colors, values, average_cell_temp)

        # Return the image source for the Img component
        return f"data:image/png;base64,{encoded_image}"

# Callback to update the graph based on the selected date range and button clicks
@app.callback(
    Output('line-chart', 'figure'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date'),
     Input('regeneration-button', 'n_clicks'),
     Input('battery-button', 'n_clicks')]
)
def update_graph(start_date, end_date, regen_clicks, battery_clicks):
    # Determine which button was last clicked
    ctx = dash.callback_context
    if not ctx.triggered:
        button_id = 'regeneration-button'
    else:
        button_id = ctx.triggered[0]['prop_id'].split('.')[0]

    # Filter the data based on the selected date range and the specified conditions
    filtered_date_df = filtered_df[(filtered_df['eDate'] >= pd.to_datetime(start_date)) & (filtered_df['eDate'] <= pd.to_datetime(end_date))]

    if button_id == 'battery-button':
        # Group by the 3-hour batches and calculate the difference for "fuelLevel"
        batch_data = filtered_date_df.groupby('3hr_batch')['fuelLevel'].apply(calculate_difference).reset_index()
        # Filter out negative differences
        batch_data = batch_data[batch_data['fuelLevel'] > 0]
        # Create the line plot for "Battery Energy Consumed"
        fig = px.line(batch_data, x='3hr_batch', y='fuelLevel', title='Difference in Fuel Level per 3-Hour Batch', color_discrete_sequence=['green'])
        fig.update_layout(xaxis_title='Time', yaxis_title='Difference in Fuel Level')
    else:
        # Group by the 3-hour batches and calculate the difference for "Regeneration Power"
        batch_data = filtered_date_df.groupby('3hr_batch')['Regeneration Power'].apply(calculate_difference).reset_index()
        # Filter out negative differences
        batch_data = batch_data[batch_data['Regeneration Power'] > 0]
        # Create the line plot for "Regeneration Power"
        fig = px.line(batch_data, x='3hr_batch', y='Regeneration Power', title='Difference in Regeneration Power per 3-Hour Batch', color_discrete_sequence=['orange'])
        fig.update_layout(xaxis_title='Time', yaxis_title='Difference in Regeneration Power')

    return fig

# Define callback to update map plot based on date range selection
@app.callback(
    Output('map-plot', 'figure'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_map(start_date, end_date):
    # Convert date strings to datetime objects
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)

    # Filter data based on the selected date range
    filtered_data = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]

    # Check if filtered data is empty
    if filtered_data.empty:
        return go.Figure()

    # Group data by hourly intervals and calculate average latitude and longitude
    hourly_data = filtered_data.groupby(filtered_data['eDate'].dt.hour).agg({'Latitude': 'mean', 'Longitude': 'mean'}).reset_index()

    coords = list(zip(hourly_data['Latitude'], hourly_data['Longitude']))

    # Get directions
    route_coords = get_directions(coords)
    if not route_coords:
        return go.Figure()

    route_lat = [coord[1] for coord in route_coords]
    route_lon = [coord[0] for coord in route_coords]

    # Create the main route plot
    fig = go.Figure(go.Scattermapbox(
        mode="lines",
        lon=route_lon,
        lat=route_lat,
        line=dict(width=2, color='blue')
    ))

    # Add maintenance center markers
    for center in maintenance_centers:
        fig.add_trace(go.Scattermapbox(
            mode="markers",
            lon=[center['lon']],
            lat=[center['lat']],
            marker={'size': 15, 'color': 'red'},
            text=center['name'],
            name=center['name']
        ))

    fig.update_layout(
        margin={'l': 0, 't': 0, 'b': 0, 'r': 0},
        mapbox={
            'style': "open-street-map",
            'zoom': 15,
            'center': {'lon': 76.7794, 'lat': 30.7333}
        }
    )

    return fig

# Define callback to update the graph based on the selected button
@app.callback(
    Output('energy-graph', 'figure'),
    [Input('motor-button', 'n_clicks'),
     Input('hvac-button', 'n_clicks')],
    [State('date-picker-range2', 'start_date'),
     State('date-picker-range2', 'end_date')]
)
def update_graph(n_clicks_motor, n_clicks_hvac, start_date, end_date):
    # Determine which button was clicked
    ctx = dash.callback_context
    if not ctx.triggered:
        button_id = 'motor-button'
    else:
        button_id = ctx.triggered[0]['prop_id'].split('.')[0]

    if button_id == 'motor-button':
        # Filter data for the selected date range
        filtered_motor_df = df[(df['eDate'] >= pd.to_datetime(start_date)) & (df['eDate'] <= pd.to_datetime(end_date))]

        # Calculate 3-hour averages for motor data
        motor_df = filtered_motor_df[['eDate', 'MotorCurrent', 'MotorVoltage']].copy()
        motor_df.set_index('eDate', inplace=True)
        three_hour_averages = motor_df.resample('3H').mean().reset_index()
        three_hour_averages['MotorEnergy'] = three_hour_averages['MotorCurrent'] * three_hour_averages['MotorVoltage']
        three_hour_averages.interpolate(method='linear', inplace=True)

        # Create motor energy graph
        fig = px.line(three_hour_averages, x='eDate', y='MotorEnergy',
                      labels={'x': 'eDate', 'y': 'Motor Energy (Joules)'}, markers=False)
        fig.update_layout(title="Average Motor Energy Over Time (3-Hour Intervals)",
                          xaxis_title="eDate", yaxis_title="Motor Energy (Joules)")

    elif button_id == 'hvac-button':
        # Filter data based on the selected date range and specified conditions
        filtered_date_df = filtered_df[(filtered_df['eDate'] >= pd.to_datetime(start_date)) & (filtered_df['eDate'] <= pd.to_datetime(end_date))]

        # Group by the 3-hour batches and calculate the difference for "HVAuxilaryPowerConsumption"
        batch_data = filtered_date_df.groupby('3hr_batch')['HVAuxilaryPowerConsumption'].apply(calculate_difference).reset_index()
        batch_data = batch_data[batch_data['HVAuxilaryPowerConsumption'] > 0]

        # Create HVAC energy graph
        fig = px.line(batch_data, x='3hr_batch', y='HVAuxilaryPowerConsumption',
                      title='Difference in HVAC Energy Consumption per 3-Hour Batch',
                      labels={'x': '3hr_batch', 'y': 'Difference in HVAC Energy Consumption'}, markers=False, line_shape='linear')
        fig.update_traces(line=dict(color='purple'))
        fig.update_layout(xaxis_title='Time', yaxis_title='Difference in HVAC Energy Consumption')

    return fig

@app.callback(
    Output('gauge-chart-motor', 'src'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date')
)
def update_gauge_chart(start_date, end_date):
    if start_date is not None and end_date is not None:
        # Filter the data based on the selected date range
        mask = (df['cdate'] >= start_date) & (df['cdate'] <= end_date)
        filtered_df = df.loc[mask]

        # Calculate the average motor current
        average_motor_current = filtered_df['MotorCurrent'].mean()

        # Create the gauge chart
        encoded_image = create_gauge_chart_motor(colors, values, average_motor_current)

        # Return the image source for the Img component
        return f"data:image/png;base64,{encoded_image}"
    else:
        return f"data:image/png;base64,{initial_encoded_image}"
    
# Define callback to update output
# Define callback to update output


# Define callback to update output
@app.callback(
    Output('black-odometer', 'src'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_output(start_date, end_date):
    if start_date is not None and end_date is not None:
        selected_data = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]
        if not selected_data.empty:
            mean_current = selected_data['MotorCurrent'].mean()
            mean_voltage = selected_data['MotorVoltage'].mean()
            mean_speed = selected_data['engineSpeed'].mean()
            mean_coolant_temp = selected_data['engineCoolantTemp'].mean()  # Assuming coolant temp column is named 'CoolantTemp'

            P_in, P_out, P_loss, efficiency = calculate_efficiency(mean_current, mean_voltage, mean_speed)
            motor_temp = calculate_motor_temp(P_loss, mean_coolant_temp)

            img_data = draw_gauge_chart(motor_temp)

            return f'data:image/png;base64,{img_data}'
    return None
# Define callback to update the graph based on the date range picker

@app.callback(
    [Output('output-container', 'children'),
     Output('circle-chart', 'children')],
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_output(start_date, end_date):
    selected_data = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]
    if not selected_data.empty:
        mean_current = selected_data['MotorCurrent'].mean()
        mean_voltage = selected_data['MotorVoltage'].mean()
        mean_speed = selected_data['engineSpeed'].mean()
        mean_coolant_temp = selected_data['engineCoolantTemp'].mean()  
        mean_torque = selected_data['MotorEstimatedTorque'].mean()  

        P_in, P_out, P_loss, efficiency = calculate_efficiency(mean_current, mean_voltage, mean_speed)
        efficiency_score = assign_efficiency_score(efficiency)

        torque_score = assign_torque_score(mean_torque)

        power_dissipation_score = assign_power_dissipation_score(P_loss)

        input_power_score = assign_input_power_score(P_in)

        motor_health_score = efficiency_score + torque_score + power_dissipation_score + input_power_score

        fig = go.Figure(data=[go.Pie(labels=['Motor Health Score', 'Remaining Score'],
                                     values=[motor_health_score, 400 - motor_health_score],
                                     marker=dict(colors=['green', 'red']))])
        fig.update_layout(height=280,width=370, margin=dict(l=20, r=20, t=20, b=20)
                          )


        return (
            html.Div(),
            dcc.Graph(figure=fig)
        )
    else:
        return (
            html.Div(),
            html.Div()
        )


# Define callback to update the graph based on the date range picker
@app.callback(
    Output('efficiency-graph', 'figure'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_graph(start_date, end_date):
    # Filter data for the selected date range
    filtered_efficiency_df = df[(df['eDate'] >= pd.to_datetime(start_date)) & (df['eDate'] <= pd.to_datetime(end_date))]

    # Check if necessary columns are present
    if not all(col in filtered_efficiency_df.columns for col in ['MotorCurrent', 'MotorVoltage', 'engineSpeed']):
        return {
            'data': [],
            'layout': {
                'title': 'Missing data columns',
                'xaxis': {'title': 'Date'},
                'yaxis': {'title': 'Motor Efficiency (%)'}
            }
        }

    # Calculate 3-hour averages for motor data
    efficiency_df = filtered_efficiency_df[['eDate', 'MotorCurrent', 'MotorVoltage', 'engineSpeed']].copy()
    efficiency_df.set_index('eDate', inplace=True)
    three_hour_averages = efficiency_df.resample('3H').mean().reset_index()

    # Interpolate missing values to ensure continuous lines
    three_hour_averages = three_hour_averages.interpolate()

    # Calculate efficiency
    efficiencies = three_hour_averages.apply(lambda row: calculate_efficiency(row['MotorCurrent'], row['MotorVoltage'], row['engineSpeed'])[3], axis=1)
    three_hour_averages['Efficiency'] = efficiencies

    # Create motor efficiency graph
    fig = px.line(three_hour_averages, x='eDate', y='Efficiency',
                  labels={'eDate': 'Date', 'Efficiency': 'Motor Efficiency (%)'}, markers=False)
    fig.update_layout(title="Average Motor Efficiency Over Time (3-Hour Intervals)",
                      xaxis_title="Date", yaxis_title="Motor Efficiency (%)")
    # Change line color to maroon
    fig.update_traces(line_color='maroon')

    return fig


# Define callback to update output
@app.callback(
    Output('output-container2', 'children'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_output(start_date, end_date):
    selected_data = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]
    if not selected_data.empty:
        mean_current = selected_data['MotorCurrent'].mean()
        mean_voltage = selected_data['MotorVoltage'].mean()
        mean_speed = selected_data['engineSpeed'].mean()
        mean_coolant_temp = selected_data['engineCoolantTemp'].mean()  # Assuming coolant temp column is named 'CoolantTemp'
        mean_torque = selected_data['MotorEstimatedTorque'].mean()  
        P_in, P_out, P_loss, efficiency = calculate_efficiency(mean_current, mean_voltage, mean_speed)
        motor_temp = calculate_motor_temp(P_loss, mean_coolant_temp)
        efficiency_score = assign_efficiency_score(efficiency)

        return html.Div([
            #html.H4('Mean Motor Current: {:.2f} A'.format(mean_current)),
            #html.H4('Mean Motor Voltage: {:.2f} V'.format(mean_voltage)),
            html.H4([
    html.I(className="fa fa-cog fa-1.5x", style={'color': '#0E396B', 'margin-right': '10px'}),
    html.Span('Mean Engine Speed: {:.2f} RPM'.format(mean_speed), style={'font-size': '30px'})
]),
      html.H4([
    html.I(className="fa fa-cog fa-1.5x", style={'color': '#0E396B', 'margin-right': '10px'}),
    html.Span('Mean Power consumed: {:.2f} KW'.format(P_out), style={'font-size': '30px'})
]),      #html.H4('Mean Engine Speed: {:.2f} RPM'.format(mean_speed)),
            #html.H4('Average Input Power (P_in): {:.2f} W'.format(P_in)),
            #html.H4('Average Output Power (P_out): {:.2f} W'.format(P_out)),
            html.H4([
    html.I(className="fa fa-cog fa-1.5x", style={'color': '#0E396B', 'margin-right': '10px'}),
    html.Span('Power Loss : {:.2f} KW'.format(P_loss), style={'font-size': '30px'})
]),
            html.H4([
    html.I(className="fa fa-cog fa-1.5x", style={'color': '#0E396B', 'margin-right': '10px'}),
    html.Span('Motor Efficiency: {:.2f} %'.format(efficiency), style={'font-size': '30px'})
]),
            #html.H4('Power Loss (P_loss): {:.2f} KW'.format(P_loss)),
            #html.H4('Motor Efficiency: {:.2f} %'.format(efficiency)),
            #html.H4('Motor Temperature: {:.2f} °C'.format(motor_temp)),
            html.H4([
    html.I(className="fa fa-cog fa-1.5x", style={'color': '#0E396B', 'margin-right': '10px'}),
    html.Span('Motor Torque: {:.2f} Nm'.format(mean_torque), style={'font-size': '30px'})
]),
            
        ])
    else:
        return html.H4('No data available for the selected date range.')
@app.callback(
    [Output('avg-soc-hidden', 'children'),
     Output('soc-gauge', 'figure'),
     Output('avg-max-temp-gauge', 'figure'),
     Output('avg-min-temp-gauge', 'figure')],
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_gauge(start_date, end_date):
    filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]
    
    if not filtered_df.empty:
        average_soc = filtered_df['fuelLevel'].mean()
        avg_soc_text = f'Average SOC: {average_soc:.2f}%'
    else:
        avg_soc_text = 'No data available for selected date range'
    
    avg_max_temp, avg_min_temp = calculate_avg_temp(filtered_df)
    
    # Create the line gauge figures
    fig_soc = go.Figure(go.Indicator(
        mode="gauge+number",
        value=average_soc,
        gauge={
            'shape': "bullet",
            'axis': {'range': [0, 100]},
            'bar': {'color': "green", 'thickness': 0.5},
            'threshold': {
                'line': {'color': "black", 'width': 2},
                'thickness': 0.5,
                'value': average_soc}
        }
    ))

    fig_soc.update_layout(height=75, width=440,
                          margin={'l': 23, 'r': 23, 'b': 23, 't': 23}, 
                          title='SOC')

    fig_avg_max_temp = go.Figure(go.Indicator(
        mode="gauge+number",
        value=avg_max_temp,
        gauge={
            'shape': "bullet",
            'axis': {'range': [0, 100]},
            'bar': {'color': "red", 'thickness': 0.5},
            'threshold': {
                'line': {'color': "black", 'width': 2},
                'thickness': 0.5,
                'value': avg_max_temp}
        }
    ))

    fig_avg_max_temp.update_layout(height=75, width=440, 
                                   margin={'l': 23, 'r': 23, 'b': 23, 't': 23}, 
                                   title='Avg Max Temp')

    fig_avg_min_temp = go.Figure(go.Indicator(
        mode="gauge+number",
        value=avg_min_temp,
        gauge={
            'shape': "bullet",
            'axis': {'range': [0, 100]},
            'bar': {'color': "blue", 'thickness': 0.5},
            'threshold': {
                'line': {'color': "black", 'width': 2},
                'thickness': 0.5,
                'value': avg_min_temp}
        }
    ))

    fig_avg_min_temp.update_layout(height=75, width=440, 
                                   margin={'l': 23, 'r': 23, 'b': 23, 't': 23}, 
                                   title='Avg Min Temp')
    

    return avg_soc_text, fig_soc, fig_avg_max_temp, fig_avg_min_temp


# Define the callback for updating the graph based on date selection and button clicks
@app.callback(
    Output('cycle-graph', 'figure'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date'),
     Input('charging-button', 'n_clicks'),
     Input('discharging-button', 'n_clicks')]
)
def update_graph(start_date, end_date, charging_clicks, discharging_clicks):
    ctx = dash.callback_context
    button_id = ctx.triggered[0]['prop_id'].split('.')[0]

    if button_id == 'charging-button':
        # Filter data based on date range selected by the user
        filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)].copy()

        # Charging Cycle Detection
        start_i_1, end_i_1 = find_start_end_indices(filtered_df['Charging Status'], 1)
        charging_cycles = []

        for i, (start_index, end_index) in enumerate(zip(start_i_1, end_i_1)):
            cycle_data = filtered_df[start_index:end_index + 1].copy()
            cycle_name = f'{i + 1}'
            cycle_data['Cycle'] = cycle_name
            charging_cycles.append(cycle_data)

        if charging_cycles:
            charg_c = pd.concat(charging_cycles)
            charg_c.reset_index(drop=True, inplace=True)

            # Calculate the duration of each charging cycle
            charg_c['start_time'] = charg_c.groupby('Cycle')['eDate'].transform('first')
            charg_c['end_time'] = charg_c.groupby('Cycle')['eDate'].transform('last')
            charg_c['duration'] = charg_c['end_time'] - charg_c['start_time']

            # Filter out cycles with duration less than 5 minutes and duration of 0
            charg_c = charg_c[(charg_c['duration'] >= pd.Timedelta(minutes=5)) & (charg_c['duration'] != pd.Timedelta(0))]

            # Re-number the cycles starting from 1
            charg_c['Cycle'] = pd.Categorical(charg_c['Cycle']).codes + 1

            # Prepare data for plotting
            cycle_durations = charg_c.groupby('Cycle')['duration'].max().reset_index()
            cycle_durations['duration_minutes'] = cycle_durations['duration'].dt.total_seconds() / 3600  # convert to minutes

            # Create a figure using Plotly Express (line graph)
            fig = px.line(
                cycle_durations,
                x='Cycle',
                y='duration_minutes',
                title='Charging Duration per Cycle',
                labels={'Cycle': 'Charging Cycle', 'duration_minutes': 'Duration (minutes)'},
                markers=True
            )

            # Customize the layout
            fig.update_traces(line=dict(color='darkgreen', width=2))
            fig.update_layout(xaxis_title='Charging Cycle', yaxis_title='Duration (minutes)')
        else:
            fig = px.line(title="No Charging Cycles Found in Selected Date Range")
    elif button_id == 'discharging-button':
        # Filter data based on date range selected by the user
        filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)].copy()

        # Discharge Cycle Detection
        start_i_0, end_i_0 = find_start_end_indices((filtered_df['Charging Status'] == 0) & (filtered_df['vehicleSpeed'] > 0), True)
        discharging_cycles = []

        for i, (start_index, end_index) in enumerate(zip(start_i_0, end_i_0)):
            cycle_data = filtered_df[start_index:end_index + 1].copy()
            cycle_name = f'{i + 1}'
            cycle_data['Cycle'] = cycle_name
            discharging_cycles.append(cycle_data)

        if discharging_cycles:
            discharg_c = pd.concat(discharging_cycles)
            discharg_c.reset_index(drop=True, inplace=True)

            # Calculate the duration of each discharging cycle
            discharg_c['start_time'] = discharg_c.groupby('Cycle')['eDate'].transform('first')
            discharg_c['end_time'] = discharg_c.groupby('Cycle')['eDate'].transform('last')
            discharg_c['duration'] = discharg_c['end_time'] - discharg_c['start_time']

            # Filter out cycles with duration less than 5 minutes and duration of 0
            discharg_c = discharg_c[(discharg_c['duration'] >= pd.Timedelta(minutes=15)) & (discharg_c['duration'] != pd.Timedelta(0))]

            # Re-number the cycles starting from 1
            discharg_c['Cycle'] = pd.Categorical(discharg_c['Cycle']).codes + 1

            # Prepare data for plotting
            cycle_durations_discharge = discharg_c.groupby('Cycle')['duration'].max().reset_index()
            cycle_durations_discharge['duration_minutes'] = cycle_durations_discharge['duration'].dt.total_seconds() / 3600  # convert to minutes

            # Create a figure using Plotly Express (line graph)
            fig = px.line(
                cycle_durations_discharge,
                x='Cycle',
                y='duration_minutes',
                title='Discharging Duration per Cycle',
                labels={'Cycle': 'Discharging Cycle'})

    # Customize the layout
            fig.update_traces(line=dict(color='darkorange', width=4))
            fig.update_layout(xaxis_title='Discharging Cycle', yaxis_title='Duration (minutes)')
        else:
            fig = px.line(title="No Discharging Cycles Found in Selected Date Range")
    else:
        # If neither button is clicked yet, or both buttons are clicked, default to charging graph
        # Filter data based on date range selected by the user
        filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)].copy()

        # Charging Cycle Detection
        start_i_1, end_i_1 = find_start_end_indices(filtered_df['Charging Status'], 1)
        charging_cycles = []

        for i, (start_index, end_index) in enumerate(zip(start_i_1, end_i_1)):
            cycle_data = filtered_df[start_index:end_index + 1].copy()
            cycle_name = f'{i + 1}'
            cycle_data['Cycle'] = cycle_name
            charging_cycles.append(cycle_data)

        if charging_cycles:
            charg_c = pd.concat(charging_cycles)
            charg_c.reset_index(drop=True, inplace=True)

            # Calculate the duration of each charging cycle
            charg_c['start_time'] = charg_c.groupby('Cycle')['eDate'].transform('first')
            charg_c['end_time'] = charg_c.groupby('Cycle')['eDate'].transform('last')
            charg_c['duration'] = charg_c['end_time'] - charg_c['start_time']

            # Filter out cycles with duration less than 5 minutes and duration of 0
            charg_c = charg_c[(charg_c['duration'] >= pd.Timedelta(minutes=5)) & (charg_c['duration'] != pd.Timedelta(0))]

            # Re-number the cycles starting from 1
            charg_c['Cycle'] = pd.Categorical(charg_c['Cycle']).codes + 1

            # Prepare data for plotting
            cycle_durations = charg_c.groupby('Cycle')['duration'].max().reset_index()
            cycle_durations['duration_minutes'] = cycle_durations['duration'].dt.total_seconds() / 3600  # convert to minutes

            # Create a figure using Plotly Express (line graph)
            fig = px.line(
                cycle_durations,
                x='Cycle',
                y='duration_minutes',
                title='Charging Duration per Cycle',
                labels={'Cycle': 'Charging Cycle', 'duration_minutes': 'Duration (minutes)'},
                markers=True
            )

            # Customize the layout
            fig.update_traces(line=dict(color='darkgreen', width=2))
            fig.update_layout(xaxis_title='Charging Cycle', yaxis_title='Duration (minutes)')
        else:
            fig = px.line(title="No Charging Cycles Found in Selected Date Range")

    return fig

@app.callback(
    Output('combined-doughnut-chart', 'figure'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_combined_doughnut_chart(start_date, end_date):
    # Filter data based on date range selected by the user
    filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)].copy()

    # Apply charging cycle detection logic on the filtered data
    start_i_1, end_i_1 = find_start_end_indices(filtered_df['Charging Status'], 1)
    charging_cycles = []

    for i, (start_index, end_index) in enumerate(zip(start_i_1, end_i_1)):
        cycle_data = filtered_df[start_index:end_index + 1].copy()
        cycle_name = f'{i + 1}'
        cycle_data['Cycle'] = cycle_name
        charging_cycles.append(cycle_data)
        
    charging_cycles_count = len(charging_cycles)
    
    if not charging_cycles:
        return go.Figure().update_layout(title="No Charging Cycles Found in Selected Date Range")

    charg_c = pd.concat(charging_cycles)
    charg_c.reset_index(drop=True, inplace=True)

    # Calculate the duration of each charging cycle
    charg_c['start_time'] = charg_c.groupby('Cycle')['eDate'].transform('first')
    charg_c['end_time'] = charg_c.groupby('Cycle')['eDate'].transform('last')
    charg_c['duration'] = charg_c['end_time'] - charg_c['start_time']
    
    # Filter out cycles with duration less than 5 minutes and duration of 0
    charg_c = charg_c[(charg_c['duration'] >= pd.Timedelta(minutes=5)) & (charg_c['duration'] != pd.Timedelta(0))]

    # Calculate average charge time
    average_charge_time = charg_c['duration'].mean().total_seconds() / 3600  # Convert to hours

    # Calculate charging frequency (cycles per day)
    if average_charge_time == 0:
        charging_frequency = 0
    else:
        charging_frequency = charging_cycles_count / average_charge_time

    # Calculate charge rate per cycle
    charg_c['fuel_level_diff'] = charg_c.groupby('Cycle')['fuelLevel'].transform('last') - charg_c.groupby('Cycle')['fuelLevel'].transform('first')
    charg_c['duration_hours'] = charg_c['duration'].dt.total_seconds() / 3600  # convert to hours
    charg_c['charge_rate'] = charg_c['fuel_level_diff'] / charg_c['duration_hours']

    # Aggregate charge rate for all cycles
    cycle_charge_rates = charg_c.groupby('Cycle')['charge_rate'].first().reset_index()
    total_charge_rate = (cycle_charge_rates['charge_rate'].mean()) *10

    # Create subplots
    fig = make_subplots(rows=3, cols=1, specs=[[{'type': 'pie'}], [{'type': 'pie'}], [{'type': 'pie'}]])

    # Charging Frequency Doughnut Chart
    fig.add_trace(go.Pie(
        #title='Average Charge Frequency',
        #labels=['Charging Frequency', 'Dummy'],
        values=[charging_frequency, 1 - charging_frequency],
        hole=.7,
        marker=dict(colors=['#BA560D', '#ACA39D'])  # Specify colors for the two sectors
    ), row=1, col=1)

    # Average Charge Rate Doughnut Chart
    fig.add_trace(go.Pie(
        #title='Average Charge Rate',
        #labels=['Charge Rate', 'Dummy'],
        values=[total_charge_rate, (100-total_charge_rate)],
        hole=.7,
        marker=dict(colors=['#5B307D', '#ACA39D'])  # Specify colors for the two sectors
    ), row=2, col=1)
    
        
    # Average Charge Time Doughnut Chart
    fig.add_trace(go.Pie(
        #title='Average Charge Time',
        #labels=['Average Charge Time', 'Dummy'],
        values=[average_charge_time,(24 - average_charge_time)],
        hole=.7,
        marker=dict(colors=['#0E64B3', '#ACA39D'])  # Specify colors for the two sectors
    ), row=3, col=1)

    # Update layout
    fig.update_layout(
        height=450,
        width=400,
        margin=dict(l=5, r=5, t=5, b=5),  # Set margin for the entire figure
        

        # Ensure circular shape
    #aspectratio=dict(x=1, y=1),
    autosize=False
    )

    # Add titles
    fig.update_layout(
        #title={'text': 'Combined Cell Health Chart'},
        #title_x=0.5
    )

    return fig

@app.callback(
    Output('call-status', 'children'),
    [Input('call-button', 'n_clicks')]
)
def make_call(n_clicks):
    if n_clicks > 0:
        call = client.calls.create(
            to=to_phone_number,
            from_=from_phone_number,
            url='http://demo.twilio.com/docs/voice.xml'  # You can set up your own TwiML bin URL here
        )
        return f'Calling... Call SID: {call.sid}'
    

@app.callback(
    Output('gauge-chart-speed', 'src'),
    [Input('date-picker-range2', 'start_date'), Input('date-picker-range2', 'end_date')]
)
def update_gauge_chart(start_date, end_date):
    # Filter data based on the selected date range
    mask = (df['eDate'] >= start_date) & (df['eDate'] <= end_date)
    filtered_df = df.loc[mask]
    
    # Apply the given conditions
    motion_mask = (filtered_df['Charging Status'] == 0) & (filtered_df['vehicleSpeed'] != 0)
    speed_mask = filtered_df['vehicleSpeed'] > 40
    filtered_df = filtered_df[motion_mask & speed_mask]

    # Calculate the average speed
    average_speed = filtered_df['vehicleSpeed'].mean() if not filtered_df.empty else 0

    # Map the average speed to an angle (0 to 180 degrees)
    min_speed = 0
    max_speed = 100  # Adjust according to the max speed your gauge should represent
    arrow_angle = (average_speed - min_speed) / (max_speed - min_speed) * 360

    # Draw the gauge chart
    fig, ax = plt.subplots()
    
   ## Draw circle
    circle = Wedge((0.5, 0.5), 0.3, 0, 360, color='#010D2A', ec='#1ED9F3', lw=3)
    ax.add_artist(circle)
    
    # Draw arrow
    arrow_length = 0.2
    arrow_end_x = 0.5 + arrow_length * np.cos(np.deg2rad(arrow_angle))
    arrow_end_y = 0.5 + arrow_length * np.sin(np.deg2rad(arrow_angle))
    ax.add_patch(FancyArrow(0.5, 0.5, arrow_end_x - 0.5, arrow_end_y - 0.5,
                            width=0.015, head_width=0.04, head_length=0.06, color='#FF6E04'))
    
    # Draw full circle scale markings
    num_marks = 10  # Number of marks for more space
    start_radius = 0.23  # Start point of the markings closer to the center
    mark_radius = 0.25  # End point of the markings
    for i in range(num_marks + 1):  # Add +1 to include the last mark
        angle = (360 / num_marks) * i
        x_start = 0.5 + start_radius * np.cos(np.deg2rad(angle))
        y_start = 0.5 + start_radius * np.sin(np.deg2rad(angle))
        x_end = 0.5 + mark_radius * np.cos(np.deg2rad(angle))
        y_end = 0.5 + mark_radius * np.sin(np.deg2rad(angle))
        ax.plot([x_start, x_end], [y_start, y_end], color='black', linewidth=2)
        
        # Add speed labels
        label_radius = 0.27
        x_label = 0.5 + label_radius * np.cos(np.deg2rad(angle))
        y_label = 0.5 + label_radius * np.sin(np.deg2rad(angle))
        speed_label = int((max_speed / num_marks) * i)
        ax.text(x_label, y_label, str(speed_label), horizontalalignment='center', verticalalignment='center', fontsize=10, color='white')
    
    ax.set_aspect('equal')
    ax.set_xlim(0.1, 1)  # Crop the chart horizontally
    ax.set_ylim(0.1, 1)  # Crop the chart vertically
    ax.axis('off')  # Turn off the axis
   
    # Display average speed
    ax.text(0.5, 0.3, f'Speed: {average_speed:.1f}',horizontalalignment='center', verticalalignment='center',fontsize=15, color='white') #

    plt.annotate("50", xytext=(0, 0), xy=(1.1, 2.0),
                 arrowprops=dict(arrowstyle="wedge,tail_width=0.5", color="white"),
                 bbox=dict(boxstyle="circle", facecolor="black", linewidth=2.0),
                 fontsize=45, color="white")

    #plt.title("Performance Gauge chart", loc="center", pad=20, fontsize=35, fontweight="bold")

    # Convert the plot to a PNG image
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    plt.close(fig)
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    
    return 'data:image/png;base64,{}'.format(image_base64)
# Callback to update the output based on selected date range
@app.callback(
    Output('output-data', 'children'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_output(start_date, end_date):
    global SOH
    if start_date is None or end_date is None:
        return "Please select a date range."

    filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]

    # Filter data based on Motion State condition
    #filtered_df = filtered_df[(filtered_df['Charging Status'] == 0) & (filtered_df['vehicleSpeed'] != 0)]

    if filtered_df.empty:
        return "No data available for the selected date range."

    # Ensure the data is sorted by date
    filtered_df = filtered_df.sort_values(by='eDate')
     
 
    # Calculate initial and final values for Power Input and LB Battery Voltage
    initial_power_input = filtered_df.iloc[0]['BatteryPotential_PowerInput1']
    final_power_input = filtered_df.iloc[-1]['BatteryPotential_PowerInput1']
    initial_lb_voltage = filtered_df.iloc[0]['Batt_Pack_Voltage']
    final_lb_voltage = filtered_df.iloc[-1]['Batt_Pack_Voltage']

    # Calculate differences
    power_input_diff = final_power_input - initial_power_input
    voltage_diff = final_lb_voltage - initial_lb_voltage

    # Calculate average values based on differences
    avg_power_input = power_input_diff 
    avg_lb_voltage = voltage_diff 

    # Calculate discharge current
    discharge_current = calculate_discharge_current(power_input_diff, voltage_diff)
    #discharge_current= 24 
    
    # Calculate discharge time
    initial_eDate = filtered_df.iloc[0]['eDate']
    final_eDate = filtered_df.iloc[-1]['eDate']
    discharge_time = (final_eDate - initial_eDate).total_seconds() / 3600  # Convert to hours

    # Calculate battery capacity
    battery_capacity = calculate_battery_capacity(discharge_current, discharge_time)

    # Calculate State of Health (SOH)
    SOH = round(abs((battery_capacity / 235) * 100), 2)

    return html.Div([
        html.H5(f"State of Health (SOH): {SOH:.2f}%"),SOH
    ])

# Update the battery visualization based on the SOH value
@app.callback(
    Output('soh-battery', 'figure'),
    Input('soh-battery', 'id')  # This is just a dummy input to trigger the callback
)
def update_battery(_):
    fig = go.Figure()

    # Draw battery outline with dark blue color
    fig.add_shape(
        type="rect",
        x0=0, x1=1, y0=0, y1=1,
        line=dict(color="#1ED9F3", width=6)
    )
    
    # Draw smaller battery terminal on the right in dark blue
    fig.add_shape(
        type="rect",
        x0=1, x1=1.2, y0=0.2, y1=0.7,
        line=dict(color="#0597B7", width=3),
        fillcolor="#0597B7"
    )

    # Fill battery with color based on SOH
    soh_color = "red" if SOH < 20 else "yellow" if SOH < 50 else "#010D2A"
    fig.add_shape(
        type="rect",
        x0=0, x1=SOH / 100, y0=0, y1=1,
        fillcolor=soh_color,
        line=dict(width=0)
    )

    fig.update_layout(
        title={'text': "Battery SOH", 'x': 0.5},
        xaxis=dict(
            showgrid=False,
            zeroline=False,
            showticklabels=False,
            range=[-0.1, 1.3]
        ),
        yaxis=dict(
            showgrid=False,
            zeroline=False,
            showticklabels=False,
            range=[-0.1, 1.1]
        ),
        shapes=[],
        annotations=[
            dict(
                x=0.5,
                y=0.5,
                text=f"{SOH}%",
                showarrow=False,
                font=dict(size=24, color="white")
            )
        ],
        margin=dict(l=30, r=30, t=30, b=30),
        paper_bgcolor="white",
        plot_bgcolor="white",
        width=355,
        height=300
    )

    return fig

@app.callback(
    [Output('gauge-chart-degrade', 'src'),
     Output('output-container-date-picker-range', 'children')],
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_output(start_date, end_date):
    # Filter data based on date range
    mask = (daily_data['eDate'] >= start_date) & (daily_data['eDate'] <= end_date)
    filtered_data = daily_data.loc[mask]

    if len(filtered_data) < 2:
        return "", "Please select a valid date range with at least two data points."

    # Fit Auto ARIMA model
    train_data = filtered_data[['eDate', 'totalDistance']]
    model = auto_arima(train_data['totalDistance'], seasonal=False, trace=False)

    # Forecast
    n_periods = 7
    forecast, conf_int = model.predict(n_periods=n_periods, return_conf_int=True)

    # Generate dates for forecasted periods (next week)
    forecast_dates = pd.date_range(start=train_data['eDate'].iloc[-1], periods=n_periods + 1, freq='D')[1:]

    # Calculate Battery Degradation Percentage
    initial_soh = 100
    final_soh = filtered_data['totalDistance'].iloc[-1] / filtered_data['totalDistance'].iloc[0] * 100
    degradation_percentage = abs(initial_soh - final_soh)

    # Create the gauge chart and encode it to base64
    encoded_image = create_gauge_chart_degrade(degradation_percentage)

    return f"data:image/png;base64,{encoded_image}", f"Date range selected: {start_date} to {end_date}"


# Function to calculate battery runtime
def calculate_battery_runtime(initial_eDate, final_eDate):
    runtime_seconds = (final_eDate - initial_eDate).total_seconds()
    hours = int(runtime_seconds // 3600)
    minutes = int((runtime_seconds % 3600) // 60)
    return f"{hours} hours {minutes} minutes"

# Callback to update the output based on selected date range
@app.callback(
    Output('output-data-clock', 'children'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_output(start_date, end_date):
    if start_date is None or end_date is None:
        return "Please select a date range."

    filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]

    if filtered_df.empty:
        return "No data available for the selected date range."

    # Ensure the data is sorted by date
    filtered_df = filtered_df.sort_values(by='eDate')

    # Calculate initial and final values for eDate
    initial_eDate = filtered_df.iloc[0]['eDate']
    final_eDate = filtered_df.iloc[-1]['eDate']

    # Calculate battery runtime
    battery_runtime = calculate_battery_runtime(initial_eDate, final_eDate)

    return html.Div([
        html.H5(f"Battery Runtime: {battery_runtime}")
    ])

# Callback to update the clock
@app.callback(Output('live-update-graph', 'figure'),
              [Input('interval-component', 'n_intervals')])
def update_graph_live(n):
    current_time = datetime.now()
    total_hours = current_time.hour + current_time.minute / 60 + current_time.second / 3600
    hour_angle = 90 - 30 * (total_hours % 24) - 0.5 * current_time.minute
    minute_angle = 90 - 6 * current_time.minute - 0.1 * current_time.second
    second_angle = 90 - 6 * current_time.second

    hour_x = 0.8 * np.cos(np.deg2rad(hour_angle))
    hour_y = 0.8 * np.sin(np.deg2rad(hour_angle))
    minute_x = 0.9 * np.cos(np.deg2rad(minute_angle))
    minute_y = 0.9 * np.sin(np.deg2rad(minute_angle))
    second_x = np.cos(np.deg2rad(second_angle))
    second_y = np.sin(np.deg2rad(second_angle))
    
    # Generate hour labels
    hour_labels = [str(i) if i != 0 else '12' for i in range(12)]

    # Generate scatter traces for hour labels with light blue color
    hour_label_traces = [go.Scatter(x=[0.85 * np.cos(np.deg2rad(-30 * i + 90))], y=[0.85 * np.sin(np.deg2rad(-30 * i + 90))],
                                    mode='text', text=hour_labels[i], textfont=dict(size=12, color='#1ED9F3'), showlegend=False)
                         for i in range(12)]

    figure = {
        'data': [
            go.Scatter(x=[-0.9, 0.9, 0.9, -0.9, -0.9], y=[-0.9, -0.9, 0.9, 0.9, -0.9], mode='lines', fill='toself', fillcolor='#010D2A', line=dict(color='#2273D2', width=5), name='Square Border'),
            go.Scatter(x=[0, hour_x], y=[0, hour_y], mode='lines+markers', marker=dict(size=1), line=dict(color='white'), name='Hour'),
            go.Scatter(x=[0, minute_x], y=[0, minute_y], mode='lines+markers', marker=dict(size=2), line=dict(color='white'), name='Minute'),
            go.Scatter(x=[0, second_x], y=[0, second_y], mode='lines+markers', marker=dict(size=3), line=dict(color='#FF6E04'), name='Second'),
            go.Scatter(x=[hour_x], y=[hour_y], mode='markers', marker=dict(size=10, color='white'), showlegend=False),
            go.Scatter(x=[minute_x], y=[minute_y], mode='markers', marker=dict(size=7, color='white'), showlegend=False),
            go.Scatter(x=[second_x], y=[second_y], mode='markers', marker=dict(size=6, color='#FF6E04'), showlegend=False)
        ]+ hour_label_traces,
        
        'layout': go.Layout(
            xaxis=dict(range=[-1, 1], visible=False),
            yaxis=dict(range=[-1, 1], visible=False),
            width=350,  # Adjust the width and height here
            height=300,
            showlegend=False,
            margin=dict(t=10, b=10, l=10, r=10)
        )
    }

    return figure

# Callback to update the output based on selected date range
@app.callback(
    Output('output-data2', 'children'),
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_output2(start_date, end_date):
    if start_date is None or end_date is None:
        return "Please select a date range."

    filtered_df = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]

    # Filter data based on Motion State condition
    #filtered_df = filtered_df[(filtered_df['Charging Status'] == 0) & (filtered_df['vehicleSpeed'] != 0)]

    if filtered_df.empty:
        return "No data available for the selected date range."

    # Ensure the data is sorted by date
    filtered_df = filtered_df.sort_values(by='eDate')

    # Calculate initial and final values for Power Input and LB Battery Voltage
    initial_power_input = filtered_df.iloc[0]['Batt_Power_In']
    final_power_input = filtered_df.iloc[-1]['Batt_Power_In']
    initial_lb_voltage = filtered_df.iloc[0]['Batt_Pack_Voltage']
    final_lb_voltage = filtered_df.iloc[-1]['Batt_Pack_Voltage']

    # Calculate differences
    power_input_diff = initial_power_input-final_power_input 
    voltage_diff = final_lb_voltage - initial_lb_voltage

    # Calculate average values based on differences
    avg_power_input = power_input_diff 
    avg_lb_voltage = voltage_diff 

    # Calculate discharge current
    discharge_current = calculate_discharge_current(power_input_diff, voltage_diff)

    # Calculate discharge time
    initial_eDate = filtered_df.iloc[0]['eDate']
    final_eDate = filtered_df.iloc[-1]['eDate']
    discharge_time = (final_eDate - initial_eDate).total_seconds() / 3600  # Convert to hours

    # Calculate battery capacity
    battery_capacity = (calculate_battery_capacity(discharge_current, discharge_time))/100

    # Calculate State of Health (SOH)
    SOH = (battery_capacity / 235) *100

    return html.Div([
        #html.H5(f"Initial Power Input: {initial_power_input:.2f} W"),
        #html.H5(f"Final Power Input: {final_power_input:.2f} W"),
        html.H5(f"Average Power Input: {avg_power_input:.2f} W"),
        #html.H5(f"Initial  Battery Voltage: {initial_lb_voltage:.2f} V"),
        #html.H5(f"Final  Battery Voltage: {final_lb_voltage:.2f} V"),
        html.H5(f"Average LB Battery Voltage: {avg_lb_voltage:.2f} V"),
        #html.H5(f"Calculated Discharge Current: {discharge_current:.2f} A"),
        html.H5(f"Discharge Time: {discharge_time:.2f} hours"),
        html.H5(f"Calculated Battery Capacity: {battery_capacity:.2f} Ah"),
        #html.H5(f"State of Health (SOH): {SOH:.2f}%"),
    ])

# Callback to update the forecast plot
@app.callback(
    Output('forecast-plot', 'figure'),
    Input('tabs', 'value')
)
def update_forecast_plot(tab):
    if tab == 'motor_power':
        trace_historical = go.Scatter(x=daily_motor_data['eDate'], y=daily_motor_data['product'], mode='lines', name='Historical Motor Power')
        trace_forecast_next_week = go.Scatter(x=forecast_motor_index, y=forecast_motor_next_week, mode='lines', name='Forecasted Motor Power')
        
        layout = go.Layout(
            title='7-Day Forecast of Motor Power',
            xaxis={'title': 'Time'},
            yaxis={'title': 'Motor Power', 'tickformat': ',.0f'},
            height=300,  # Adjust the height of the plot
            width=850    # Adjust the width of the plot
        )
        return {'data': [trace_historical, trace_forecast_next_week], 'layout': layout}
    
    elif tab == 'cell_max_temp':
        trace_historical = go.Scatter(x=daily_temp_data['eDate'], y=daily_temp_data['Max_Cell_Temp'], mode='lines', name='Historical Max Cell Temp')
        trace_forecast_next_week = go.Scatter(x=forecast_temp_dates, y=forecast_temp, mode='lines', name='Forecasted Max Cell Temp')
        
        layout = go.Layout(
            title='7-Day Forecast of Max Cell Temp',
            xaxis={'title': 'Time'},
            yaxis={'title': 'Max Cell Temp', 'tickformat': ',.0f'},
            height=300,  # Adjust the height of the plot
            width=850
        )
        return {'data': [trace_historical, trace_forecast_next_week], 'layout': layout}

    elif tab == 'battery_prediction':
        trace_historical = go.Scatter(x=daily_battery_data['eDate'], y=daily_battery_data['totalDistance'], mode='lines', name='Historical Lifetime Distance')
        trace_forecast_next_week = go.Scatter(x=forecast_battery_dates, y=forecast_battery, mode='lines', name='Forecasted Lifetime Distance')
        
        layout = go.Layout(
            title='7-Day Forecast of Lifetime Distance',
            xaxis={'title': 'Time'},
            yaxis={'title': 'Lifetime Distance', 'tickformat': ',.0f'},
            height=300,  # Adjust the height of the plot
            width=850    # Adjust the width of the plot
        )
        return {'data': [trace_historical, trace_forecast_next_week], 'layout': layout}


@app.callback(
    [Output('safety-status', 'children'),
     Output('internal-temp-display', 'children'),
     Output('vehicle-body-temp-display', 'children'),
     Output('soc-display', 'children')],
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_data(start_date, end_date):
    if start_date is not None and end_date is not None:
        hvsi = HighVoltageSafetyInterlockSystem(file_path)
        is_safe, message = hvsi.check_safety(start_date, end_date)
        
        # Calculate average coolant temperature
        average_coolant_temp = Cal_average_coolant_temp(start_date, end_date)

        # Calculate DC/DC temperature
        dcdc_temp, average_cell_temp = calculate_dcdc_temp2(start_date, end_date)

        # Calculate motor temperature
        P_loss = 1000  # Placeholder for P_loss, you need to calculate it
        motor_temp = calculate_motor_temp(P_loss, average_coolant_temp)

        # Calculate internal temperature
        internal_temp = (motor_temp + dcdc_temp + average_cell_temp + average_coolant_temp) / 4

        # Calculate body temperature of the vehicle
        body_temp = 24 + internal_temp

        # Calculate State of Charge (SOC)
        average_soc = df.loc[(df['eDate'] >= start_date) & (df['eDate'] <= end_date), 'fuelLevel'].mean()

        if is_safe:
            safety_status = html.H5("High voltage system operation allowed. Safety checks passed.", style={'font-size': '18px', 'font-style': 'italic'})
        else:
            safety_status = html.H5(f"High voltage system operation not allowed. {message}", style={'font-size': '18px', 'font-style': 'italic'})
        
        internal_temp_display = html.H5(f"Internal Temperature: {internal_temp:.2f} °C", style={'font-size': '18px', 'font-style': 'italic'})
        body_temp_display = html.H5(f"Body Temperature of the Vehicle: {body_temp:.2f} °C", style={'font-size': '18px', 'font-style': 'italic'})
        soc_display = html.H5(f"State of Charge (SOC): {average_soc:.2f}", style={'font-size': '18px', 'font-style': 'italic'})

        return safety_status, internal_temp_display, body_temp_display, soc_display
    else:
        return "", "", "", ""  # Return empty strings if start_date or end_date is None


@app.callback(
    [Output('activity-time-output', 'children'),
     Output('pie-chart', 'figure')],
    [Input('date-picker-range2', 'start_date'),
     Input('date-picker-range2', 'end_date')]
)
def update_output(start_date, end_date):
    if start_date and end_date:
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_date = datetime.strptime(end_date, '%Y-%m-%d')

        # Filter data based on selected date range
        filtered_data = df[(df['eDate'] >= start_date) & (df['eDate'] <= end_date)]

        # Calculate state summary for the selected date range
        daily_state_summary = filtered_data.groupby([filtered_data['eDate'].dt.date, 'state']).size().unstack(fill_value=0)

        # Calculate total time in motion state and idle state
        total_motion_time = daily_state_summary['motion'].sum()
        total_idle_time = daily_state_summary['idle'].sum()

        # Calculate activity time
        activity_time = (total_motion_time + total_idle_time)/60
        activity_time = activity_time.round(2)

        import plotly.graph_objs as go

        # Create pie chart
        labels = ['Activity Time', 'Remaining']
        values = [activity_time, 24 * (end_date - start_date).days - activity_time]
        colors = ['#1f77b4', '#aec7e8']  # Dark blue and light blue colors
        
        fig = go.Figure(data=[go.Pie(labels=labels, values=values)])
        fig.update_traces(marker=dict(colors=colors))
        
        # Update layout to adjust the size and placement of the pie chart
        fig.update_layout(
            width=300,  # Set the width of the figure
            height=300,  # Set the height of the figure
            margin=dict(l=0, r=0, t=0, b=0),  # Remove margins
            showlegend=True,  # Show the legend
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        return (f"{activity_time} minutes",
                fig)

    else:
        return ("", {})

@app.callback(
    Output('output-container-distance-info', 'children'),
    Input('date-picker-range2', 'start_date'),
    Input('date-picker-range2', 'end_date')
)
def update_output(start_date, end_date):
    if start_date is not None and end_date is not None:
        mask = (df['eDate'] >= start_date) & (df['eDate'] <= end_date)
        filtered_df = df.loc[mask]
        if not filtered_df.empty:
            initial_distance = filtered_df['totalDistance'].iloc[0]
            last_distance = filtered_df['totalDistance'].iloc[-1]
            distance_covered = round(last_distance - initial_distance, 2)
            
            return html.Div([
                html.Div('Predicted Distance:100.82Km', style={'font-weight': 'bold', 'font-size': '18px'}),
                html.Div('Mileage:2KmW/Km', style={'font-weight': 'bold', 'font-size': '18px'}),
                html.Div(f"Distance Covered: {distance_covered:.2f}Km", style={'font-weight': 'bold', 'font-size': '18px'}),
                       ])
        else:
            return 'No data available for the selected date range'
    else:
        return 'Please select a date range'

@app.callback(
    Output('health-score-doughnut', 'figure'),
    Input('date-picker-range2', 'start_date'),
    Input('date-picker-range2', 'end_date')
)
def update_health_score_doughnut(start_date, end_date):
    if start_date is not None and end_date is not None:
        mask = (df['eDate'] >= start_date) & (df['eDate'] <= end_date)
        filtered_df = df.loc[mask]
        if not filtered_df.empty:
            initial_distance = filtered_df['totalDistance'].iloc[0]
            last_distance = filtered_df['totalDistance'].iloc[-1]
            distance_covered = round(last_distance - initial_distance, 2)
            
            mileage = 9
            motor_voltage = filtered_df['Batt_Pack_Voltage'].mean()
            temperature = filtered_df['Min_Cell_Temp'].mean()
            battery_health = 95

            # Define normalization functions for each metric
            def normalize_distance_covered(distance):
                expected_lifespan = 200000  # in kilometers
                return min(distance / expected_lifespan, 1)

            def normalize_mileage(mileage):
                typical_mileage = 12  # in km/l
                return min(mileage / typical_mileage, 1)

            def normalize_motor_voltage(voltage):
                typical_voltage = 48  # expected motor voltage in volts
                return min(voltage / typical_voltage, 1)

            def normalize_temperature(temp):
                optimal_temp_range = (70, 100)  # in degrees Celsius
                if temp < optimal_temp_range[0]:
                    return 0
                elif temp > optimal_temp_range[1]:
                    return 0
                else:
                    return (optimal_temp_range[1] - temp) / (optimal_temp_range[1] - optimal_temp_range[0])

            def normalize_battery_health(voltage):
                typical_voltage = 12.6  # in volts
                return min(voltage / typical_voltage, 1)

            # Calculate the overall health score
            health_score = (
                normalize_distance_covered(distance_covered) * 0.25 +
                normalize_mileage(mileage) * 0.25 +
                normalize_motor_voltage(motor_voltage) * 0.25 +
                normalize_temperature(temperature) * 0.15 +
                normalize_battery_health(battery_health) * 0.10
            ) * 100

            # Create the doughnut chart
            fig = go.Figure(go.Pie(
                values=[health_score, 100 - health_score],
                hole=0.4,  # This controls the size of the inner hole
                marker=dict(colors=['#36a2eb', 'lightgrey']),
                labels=['Health Score', ''],
                textinfo='none',
                domain=dict(x=[0.1, 0.9], y=[0.1, 0.9])  # Adjust the domain to control the outer radius
            ))

            fig.update_layout(
                title='Vehicle Health Score',
                annotations=[dict(text=f'{health_score:.2f}%', x=0.5, y=0.5, font_size=20, showarrow=False)],
                height=350,  # Adjust the height here
                width=400,
                margin=dict(l=20, r=20, t=10, b=20)
            )

            return fig
        else:
            return {}
    else:
        return {}

@app.callback(
    Output('output-container-vehicle-rating', 'children'),
    Input('date-picker-range2', 'start_date'),
    Input('date-picker-range2', 'end_date')
)
def update_output(start_date, end_date):
    global health_score
    if start_date is not None and end_date is not None:
        mask = (df['eDate'] >= start_date) & (df['eDate'] <= end_date)
        filtered_df = df.loc[mask]
        if not filtered_df.empty:
            initial_distance = filtered_df['totalDistance'].iloc[0]
            last_distance = filtered_df['totalDistance'].iloc[-1]
            distance_covered = round(last_distance - initial_distance, 2)
            
            mileage = 9
            motor_voltage = filtered_df['Batt_Pack_Voltage'].mean()
            temperature = filtered_df['Min_Cell_Temp'].mean()
            battery_health = 90

            # Define normalization functions for each metric
            def normalize_distance_covered(distance):
                expected_lifespan = 200000  # in kilometers
                return min(distance / expected_lifespan, 1)

            def normalize_mileage(mileage):
                typical_mileage = 12  # in km/l
                return min(mileage / typical_mileage, 1)

            def normalize_motor_voltage(voltage):
                typical_voltage = 48  # expected motor voltage in volts
                return min(voltage / typical_voltage, 1)

            def normalize_temperature(temp):
                optimal_temp_range = (70, 100)  # in degrees Celsius
                if temp < optimal_temp_range[0]:
                    return 0
                elif temp > optimal_temp_range[1]:
                    return 0
                else:
                    return (optimal_temp_range[1] - temp) / (optimal_temp_range[1] - optimal_temp_range[0])

            def normalize_battery_health(health):
                return min(health / 100, 1)

            # Normalize each metric
            normalized_metrics = {
                'distance_covered': normalize_distance_covered(distance_covered),
                'mileage': normalize_mileage(mileage),
                'motor_voltage': normalize_motor_voltage(motor_voltage),
                'temperature': normalize_temperature(temperature),
                'battery_health': normalize_battery_health(battery_health)
            }

            print("Normalized Metrics:", normalized_metrics)

            # Define weightage for each metric
            weights = {
                'distance_covered': 0.25,
                'mileage': 0.25,
                'motor_voltage': 0.25,
                'temperature': 0.15,
                'battery_health': 0.10
            }

            # Calculate the overall health score
            health_score = sum(weights[metric] * normalized_metrics[metric] for metric in weights)

            # Print the health score
            print(f"Health Score: {health_score * 100:.2f}%")

            # Calculate the vehicle rating
            vehicle_rating = calculate_vehicle_rating(health_score)
            print(f"Vehicle Rating (out of 5): {vehicle_rating:.2f}")

            # Generate stars based on the vehicle rating
            star_count = int(vehicle_rating)
            star_url = "https://img.freepik.com/free-vector/star-glossy-yellow-colors-3d-cute-smooth-star-shape-realistic-vector-illustration-isolated-white-background_145391-1342.jpg?t=st=1717736068~exp=1717739668~hmac=6b791e05873ebc6e5456e49a2b0f07692c4c09a339612371d232ec42cde48be5&w=826"
            stars = [html.Img(src=star_url, style={'height': '50px'}) for _ in range(star_count)]

            return html.Div([
                   html.Div(f'Vehicle Points: {health_score * 100:.2f}', style={'font-size': '20px'}),
                   html.Div(f'Vehicle Rating (out of 5): {vehicle_rating:.2f}', style={'font-size': '20px'}),
                   html.Div(stars)
            ])
        else:
            return 'No data available for the selected date range'
    else:
        return 'Please select a date range'
    
def calculate_vehicle_rating(health_score):
    total_score = 1  # Since health_score is already a fraction out of 1
    normalized_rating = (health_score / total_score) * 5
    return normalized_rating

@app.callback(
    Output('output-container-pmo', 'children'),
    Output('image-box', 'children'),
    Input('date-picker-range2', 'start_date'),
    Input('date-picker-range2', 'end_date')
)
def update_output(start_date, end_date):
    global health_score
    if start_date is not None and end_date is not None:
        mask = (df['eDate'] >= start_date) & (df['eDate'] <= end_date)
        filtered_df = df.loc[mask]
        if not filtered_df.empty:
            initial_distance = filtered_df['totalDistance'].iloc[0]
            last_distance = filtered_df['totalDistance'].iloc[-1]
            distance_covered = round(last_distance - initial_distance, 2)
            
            mileage = 9
            motor_voltage = filtered_df['Batt_Pack_Voltage'].mean()
            temperature = filtered_df['Min_Cell_Temp'].mean()
            battery_health = 90

            def normalize_distance_covered(distance):
                expected_lifespan = 200000  # in kilometers
                return min(distance / expected_lifespan, 1)

            def normalize_mileage(mileage):
                typical_mileage = 12  # in km/l
                return min(mileage / typical_mileage, 1)

            def normalize_motor_voltage(voltage):
                typical_voltage = 48  # expected motor voltage in volts
                return min(voltage / typical_voltage, 1)

            def normalize_temperature(temp):
                optimal_temp_range = (70, 100)  # in degrees Celsius
                if temp < optimal_temp_range[0]:
                    return 0
                elif temp > optimal_temp_range[1]:
                    return 0
                else:
                    return (optimal_temp_range[1] - temp) / (optimal_temp_range[1] - optimal_temp_range[0])

            def normalize_battery_health(voltage):
                typical_voltage = 12.6  # in volts
                return min(voltage / typical_voltage, 1)

            normalized_metrics = {
                'distance_covered': normalize_distance_covered(distance_covered),
                'mileage': normalize_mileage(mileage),
                'motor_voltage': normalize_motor_voltage(motor_voltage),
                'temperature': normalize_temperature(temperature),
                'battery_health': normalize_battery_health(battery_health)
            }

            weights = {
                'distance_covered': 0.25,
                'mileage': 0.25,
                'motor_voltage': 0.25,
                'temperature': 0.15,
                'battery_health': 0.10
            }
            
            health_score = sum(weights[metric] * normalized_metrics[metric] for metric in weights)
            selected_image_src = select_image(health_score)

            return html.Div([
                #html.Div(f'{health_score * 100:.2f}%', style={'font-size': '12px'})
            ]), html.Img(src=selected_image_src, style={'width': '80px', 'height': '80px', 'objectFit': 'cover', 'marginRight': '10px'})
        else:
            return 'No data available for the selected date range', ''
    else:
        return 'Please select a date range', ''
    
@app.callback(
    [Output('page-content', 'children'),
     Output('page-1-link', 'style'),
     Output('page-2-link', 'style'),
     Output('page-3-link', 'style'),
     Output('page-4-link', 'style'),
     Output('page-5-link', 'style'),
     Output('page-6-link', 'style')],
    [Input('page-1-link', 'n_clicks'),
     Input('page-2-link', 'n_clicks'),
     Input('page-3-link', 'n_clicks'),
     Input('page-4-link', 'n_clicks'),
     Input('page-5-link', 'n_clicks'),
     Input('page-6-link', 'n_clicks')]
)



def switch_page(page1_clicks, page2_clicks, page3_clicks, page4_clicks, page5_clicks,page6_clicks):
    ctx = callback_context
    if not ctx.triggered:
        return [
            [
                #elongated_rectangle,
                card1,
                
            ],
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'}
        ]

    button_id = ctx.triggered[0]['prop_id'].split('.')[0]

    if button_id == 'page-1-link':
        return [html.Div(
        children=[
            # Row for the date selectors
            html.Div(
                children=[card1, card10],
                style={'display': 'flex', 'flexDirection': 'row','gap': '10px', 'marginBottom': '10px'}
            ),
                html.Div([
                    html.Div(
                        children=[
                            html.Div([cardhealthscore,cardwarnings], style={'flex': '1', 'marginRight': '10px', 'display': 'flex', 'flexDirection': 'row', 'gap': '10px'}),
                            html.Div(
                                children=[
                                    html.Div([cardvehiclerating], style={'marginBottom': '10px'}),
                                    html.Div([carddistanceinfo])
                                ],
                                style={'flex': '1', 'display': 'flex', 'flexDirection': 'column'}
                            )
                        ],
                        style={'display': 'flex', 'flexDirection': 'row'}
                    ),
                    
                    #html.Div([carddistanceinfo, cardhealthscore,cardvehiclerating], style={'display': 'flex', 'flexDirection': 'row'}),
                    html.Div([arima_forecasting,cardoperatingrate], style={'display': 'flex', 'flexDirection': 'row'}),
                    html.Div([card_diagnostic_trouble_codes,cardvehicleinfo,card_predictive_maintenance], style={'display': 'flex', 'flexDirection': 'row'}),
              
                ], style={'display': 'flex', 'flexDirection': 'column'})
            ]),
            
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#6D6F71'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'}
        ]
    elif button_id == 'page-2-link':
     return [
        html.Div(
            children=[
                # Row for the date selectors
                html.Div(
                    children=[card1, card10],
                    style={'display': 'flex', 'flexDirection': 'row','gap': '10px', 'marginBottom': '10px'}
                ),
                html.Div(
                    children=[
                        html.Div([card2, cardSOH, cardspeed], style={'display': 'flex', 'flexDirection': 'row'}),
                        html.Div(
                            children=[
                                html.Div([cardbattpred], style={'flex': '1', 'marginRight': '10px'}),
                                html.Div(
                                    children=[
                                        html.Div([cardbatteryinfo], style={'marginBottom': '10px'}),
                                        html.Div([cardbatterydeg])
                                    ],
                                    style={'flex': '1', 'display': 'flex', 'flexDirection': 'column'}
                                )
                            ],
                            style={'display': 'flex', 'flexDirection': 'row'}
                        )
                    ],
                    style={'display': 'flex', 'flexDirection': 'column'}
                ),
            ],
            style={'display': 'flex', 'flexDirection': 'column'}
        ),
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#6D6F71'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'}
    ]




    elif button_id == 'page-3-link':
        return [
        html.Div(
    children=[
        # Row for the date selectors
        html.Div(
            children=[card1, card10],
            style={'display': 'flex', 'flexDirection': 'row','gap': '10px', 'marginBottom': '10px'}
        ),
            html.Div([
                html.Div([cardcellinfo, cardcellstate,cardcellscore], style={'display': 'flex', 'flexDirection': 'row'}),
                html.Div([cardcellcycle,cardcellcombine], style={'display': 'flex', 'flexDirection': 'row'}),
            ], style={'display': 'flex', 'flexDirection': 'column'})
        ]),
        # Styles for cards and links
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#6D6F71'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'}
        ]
    elif button_id == 'page-4-link':
        return [
        html.Div(
    children=[
        # Row for the date selectors
        html.Div(
            children=[card1, card10],
            style={'display': 'flex', 'flexDirection': 'row','gap': '10px', 'marginBottom': '10px'}
        ),
            html.Div([
                html.Div([cardmotorhealth,cardmotortemp,cardmotorcurrentemp], style={'display': 'flex', 'flexDirection': 'row'}),
                html.Div([cardmotorefficiency,cardmotorinfo], style={'display': 'flex', 'flexDirection': 'row'}),
            ], style={'display': 'flex', 'flexDirection': 'column'})
        ]),
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#6D6F71'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
            {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'}
        ]
    elif button_id == 'page-5-link':
        return [
        html.Div(
    children=[
        # Row for the date selectors
        html.Div(
            children=[card1, card10],
            style={'display': 'flex', 'flexDirection': 'row','gap': '10px', 'marginBottom': '10px'}
        ),
            html.Div([
                html.Div([card5, card6, card7], style={'display': 'flex', 'flexDirection': 'row'}),
                html.Div([card8, card11], style={'display': 'flex', 'flexDirection': 'row'}),
            ], style={'display': 'flex', 'flexDirection': 'column'})
        ]),
        # Styles for cards and links
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#6D6F71'},
        {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'}
    ]

    elif button_id == 'page-6-link':
        return [
            html.Div([
                card10,
                html.Div([
                    card9
                ], style={'display': 'flex', 'flexDirection': 'column'})
            ]),
            # Styles for cards and links
                {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
                {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
                {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
                {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
                {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#0E396B'},
                {'color': 'white', 'textDecoration': 'none', 'display': 'block', 'padding': '10px', 'backgroundColor': '#6D6F71'}
        ]
    
if __name__ == '__main__':
    app.run_server(debug=True)
